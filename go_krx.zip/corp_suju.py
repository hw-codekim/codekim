import pandas as pd
import OpenDartReader
import requests as rq
from bs4 import BeautifulSoup
from html_table_parser import parser_functions as parser
import re
from tqdm import tqdm
import time
# from fake_useragent import UserAgent

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'}
# ua=UserAgent(use_cache_server=True)
# headers = {'User-Agent':ua.random}
api_key = '08d5ae18b24d9a11b7fd67fb0d79c607f1c88464'
dart = OpenDartReader(api_key)
def oder_backlog(code,name):

    #기간
    lists = dart.list(code, start='2020-01-01', end ='2024-12-15', kind='A') 
    lists['공시'] = lists['report_nm'].str.split(' ').str[1]
    #수준잔고 확인
    rcp_no = []
    for i in range(0,len(lists)):
        rcp = lists['rcept_no'][i]
        rcp_no.append(rcp)  
        

    df = pd.DataFrame()
    comment = '수주잔고'

    for j in tqdm(range(0,len(rcp_no))):

        files = dart.sub_docs(rcp_no[j])
        content = [] #
        content_old = []
        if '제품' in files['title']:
            
            data = files[files['title'].str.contains('제품')]

            try:
                a = data['url'].values[0]
                res = rq.get(a,headers=headers)
                soup=BeautifulSoup(res.text,'html.parser')
                temp = soup.select('body > table')
                
                for v in temp:
                    text = v.get_text()
                    if comment in text : 
                        content.append(v)
                table = parser.make2d(content[0]) #표로 만들어줌
                adata = pd.DataFrame(table) # 필요한부분만 불러옴
                adata.columns = adata.iloc[0]
                adata = adata.iloc[-1:,:]
                adata = adata.dropna(axis=1, how="all")
                adata = adata.iloc[:,-1:]
                adata.columns=['수주잔고']
                adata.insert(0,'날짜',lists['공시'][j])
                adata.insert(0,'기업명',name)
                
                df = pd.concat([df,adata])
                time.sleep(2)
                
            except:
                print('넘어가자')
                    
        else:     
                
            data_old = files[files['title'].str.contains('사업의 내용')]

            try:
                b = data_old['url'].values[0]
                res_old = rq.get(b,headers=headers)
                soup_old=BeautifulSoup(res_old.text,'html.parser')
                tem = soup_old.select('body > table')

                for k in tem:
                    text = k.get_text().strip()

                    if comment in text : 
                        content_old.append(k)
                
                atable = parser.make2d(content_old[0]) #표로 만들어줌
                
                adata = pd.DataFrame(atable) # 필요한부분만 불러옴
                adata.columns = adata.iloc[0]
            
                adata = adata.iloc[-1:,:]
                adata = adata.dropna(axis=1, how="all")
                adata = adata.iloc[:,-1:]
                adata.columns=['수주잔고']
                adata.insert(0,'날짜',lists['공시'][j])
                adata.insert(0,'기업명',name)
                
                
                df = pd.concat([df,adata])
                time.sleep(2)
            except:
                print('이것도 넘어가자')
    # df.to_clipboard()
    return df

def save(corpData,name):
    file_name = './수주잔고/수주잔고.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    corpData.to_excel(
        writer, 
        sheet_name=name,
        startcol = 0,
        startrow = writer.sheets[name].max_row,
        index=False, 
        na_rep = '',      # 결측값을 ''으로 채우기
        inf_rep = '',     # 무한값을 ''으로 채우기
        header = None
        )
    writer.close()
    
if __name__ == '__main__':
    corp = {
        '071970':'HD현대마린엔진',
        '077970':'STX엔진',
        '082740':'한화엔진',
        '101930':'인화정공',
        '073010':'케이에스피',
        '014940':'오리엔탈정공',
        '075580':'세진중공업',
        '017960':'한국카본',
        '033500':'동성화인텍',
        '108380':'대양전기공업',
        '092460':'한라IMS',
        
    }
    
    for code,name in corp.items():
        try:
            corpData = oder_backlog(code,name)
            save(corpData,name)
        except Exception as e:
            print(name,e)