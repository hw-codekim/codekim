import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.font_manager as fm

warnings.filterwarnings("ignore")

def get_whynot_report(db,date):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from whynot_report
        where 1=1
        and date = '{date}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['id','날짜','종목명','이름','목표가','판단','제목','내용','애널순위','애널코드','애널id'])
    return df

def get_krx_daily_price(db,date):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from krx_daily_price
        where 1=1
        and 기준일 = '{date}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','시장구분','소속부','종가','대비','등락률','시가','고가','저가','거래량','거래대금','시가총액','상장주식수'])
    df = df.sort_values('등락률',ascending=False)
    return df

def get_name_krx_daily_price(db,name):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select 기준일,종목명,시가총액,거래대금 from krx_daily_price
        where 1=1
        and 종목명 = '{name}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목명','시가총액','거래대금'])
    df = df.sort_values('기준일')
    return df



def get_krx_trade_amount(db,date):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from krx_trade_amount
        where 1=1
        and 기준일 = '{date}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','금융투자','보험','투신','사모','은행','기타금융','연기금등','기타법인','개인','외국인','기타외국인','전체'])
    # 하이라이트 함수 정의
    to_df = df.sort_values('투신',ascending=False)[['기준일','종목명','투신']][:16]
    sa_df = df.sort_values('사모',ascending=False)[['기준일','종목명','사모']][:16]
    y_df = df.sort_values('연기금등',ascending=False)[['기준일','종목명','연기금등']][:16]
    ddf = pd.concat([to_df,sa_df,y_df],axis=0)
    return ddf


def get_name_krx_trade_amount(db,corp):

    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],   
            charset='utf8mb4'                  
            )
    mycursor = con.cursor()
    sql = f"""
        select * from krx_trade_amount
        where 1=1
        and 종목명 = '{corp}' 
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','금융투자','보험','투신','사모','은행','기타금융','연기금등','기타법인','개인','외국인','기타외국인','전체'])
    return df




def get_name_krx_daily_price(db,name):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select 기준일,종목명,시가총액,거래대금 from krx_daily_price
        where 1=1
        and 종목명 = '{name}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목명','시가총액','거래대금'])
    return df

def get_naver_theme(db,date):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from naver_theme
        where 1=1
        and 등락률 >= 5.0
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','테마','종목명','테마사유','현재가', '등락률','거래량', '거래대금','전일거래량'])
    df = df.sort_values('등락률',ascending=False)
    df['거래증감률'] = round(((df['거래량'] - df['전일거래량'])/df['전일거래량'])*100,1)
    return df

def get_naver_group(db,date):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from naver_group
        where 1=1
        and 기준일 = '{date}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','그룹','종목명','현재가', '등락률','거래량', '거래대금','전일거래량'])
    df = df[~df['그룹'].str.contains('기타')]
    df['거래증감률'] = round(((df['거래량'] - df['전일거래량'])/df['전일거래량'])*100,1)
    df = df[(df['거래증감률'] > 0) & (df['거래증감률'] != np.inf) & (df['등락률'] > 0 )& (df['거래대금'] > 100 )]
    df = df.sort_values('거래증감률',ascending=False)
    return df



if __name__ == '__main__':
    date = working_day()
    db = connDB.db_conn()
    
    # corp = '지누스'
    
    # whynot_df = get_whynot_report(db,date)
    # daily_price = get_krx_daily_price(db,date)
    # trade_amount = get_krx_trade_amount(db,date)
    # naver_theme(db,date)
  
    # # # print(trade_amount.columns)
    # # merged_df = pd.merge(daily_price, trade_amount, on=['기준일', '종목코드'], how='outer')
    # # merged_df = merged_df.sort_values('등락률',ascending=False)
    # whynot_df.to_clipboard()
    # amount = get_name_krx_trade_amount(db,corp)
    # price = get_name_krx_daily_price(db,corp)
    # print(amount)
    # a = get_naver_group(db,date)
    # # # tosin = amount['투신'].rolling(window=5).mean()
    # a.to_clipboard()
    # print(a)
    
    
    
    name = '지누스'
    price = get_name_krx_daily_price(db,name)
    price['기준일'] = pd.to_datetime(price['기준일']).dt.strftime('%Y%m%d')
    price = price.loc['20240102':]
    print(price)

    # print(price.info())
    
    # 한글 폰트 설정 (Windows에서 '맑은 고딕' 사용)
    font_path = 'C:\\Windows\\Fonts\\malgun.ttf'  # 또는 malgunbd.ttf (볼드체)
    fontprop = fm.FontProperties(fname=font_path, size=10)
    # 그래프 설정
    fig, ax1 = plt.subplots(figsize=(8, 5))

    # 첫 번째 y축에 대한 거래대금 선 그리기
    # sns.lineplot(data=price, x='기준일', y='거래대금', ax=ax1, label='거래대금', color='blue')
    sns.barplot(data=price, x='기준일', y='거래대금', ax=ax1, color='blue', label='거래대금', alpha=0.7)
    ax1.set_ylabel('거래대금', color='blue', fontproperties=fontprop)
    ax1.tick_params(axis='y', labelcolor='blue')

    # 두 번째 y축 생성
    ax2 = ax1.twinx()
    sns.lineplot(data=price, x='기준일', y='시가총액', ax=ax2, label='종가', color='red')
    ax2.set_ylabel('시가총액', color='orange', fontproperties=fontprop)
    ax2.tick_params(axis='y', labelcolor='orange')

    # 그래프 꾸미기
    plt.title(f'{name} _ 거래대금과 종가', fontproperties=fontprop)  # 한글 폰트 설정
    ax1.axhline(0, color='black', lw=0.5, ls='--')  # x축 추가
    ax1.axvline(0, color='black', lw=0.5, ls='--')  # y축 추가
    ax1.set_axisbelow(True)  # 축을 아래에 설정
    ax1.grid(True, zorder=0)  # grid를 앞쪽

    ax1.grid(True)

    # 범례 추가
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2,prop=fontprop)
    
    ax1.set_xlabel('')  # x축 레이블 제거
    ax1.xaxis.set_tick_params(rotation=90)  # x축 날짜 레이블을 90도 회전
    # ax1.grid(True, zorder=0)  # grid를 앞쪽에 위치
    plt.tight_layout()  # 레이아웃 조정
    plt.show()