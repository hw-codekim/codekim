# go_krx
git 에 등록한 krx 레포지토리의 데이터를 가지고 실행 
