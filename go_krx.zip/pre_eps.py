import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day


def get_krx_value(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT * FROM krx_value
        where 선행EPS is not null
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','종가','대비','등락률','EPS','PER','선행EPS','선행PER','BPS','PBR','주당배당금','배당수익률'])
    # df = df[['기준일','그룹','종목명','현재가','등락률','거래량','거래대금','전일거래량','시가총액','거래변동률','거래시총비율']]
    # df = df['거래변동율'].astype(float)
    
    return df

if __name__ == '__main__':
    date = working_day()
    db = connDB.db_conn()
    biz_day = working_day()
    # biz_day = '20241021'

 
    final = get_krx_value(db,biz_day)
    final.to_clipboard()
    # print(final)