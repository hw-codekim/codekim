import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day


def get_whynot_report(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT date,company_name FROM whynot_report
        WHERE 1=1
        AND DATE = '{biz_day}';
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목명'])
    print(f'금일 레포트 개수 : {len(df)}')
    df = df.drop_duplicates('종목명')
    return df

def get_corp_whynot_report(db,corp):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT * FROM whynot_report
        WHERE 1=1
        AND company_name = '{corp}';
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['id','기준일','종목명','애널','목표가','판단','제목','내용','애널순위','스탁코드','애널id'])
    df = df.sort_values(by=['애널id','기준일'])
    
    return df

def classify_change(row, previous_row):
    if previous_row is None:
        return 'No prior data'
    elif row['목표가'] > previous_row['목표가']:
        return 'Increased'
    elif row['목표가'] < previous_row['목표가']:
        return 'Decreased'
    else:
        return 'No change'

def get_krx_daily_price(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from krx_daily_price
        WHERE 1=1
        AND 기준일 = '{biz_day}'
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','시장구분','소속부','종가','대비','등락률','시가','고가','저가','거래량','거래대금','시가총액','상장주식수'])
    df = df[['기준일','종목명','종가','등락률']]
    return df

def save(increased_df):
    file_name = './report_increased/상향레포트_요약.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    increased_df.to_excel(
        writer, 
        sheet_name='Sheet1',
        startcol = 0,
        startrow = writer.sheets['Sheet1'].max_row,
        index=False, 
        na_rep = '',      # 결측값을 ''으로 채우기
        inf_rep = '',     # 무한값을 ''으로 채우기
        header = None
        )
    writer.close()


if __name__ == '__main__':
    date = working_day()
    db = connDB.db_conn()
    biz_day = working_day()
    # biz_day = '20241029'
 
    final = get_whynot_report(db,biz_day)
    price = get_krx_daily_price(db,biz_day)
    
    corp_list = final['종목명']
    
    daily_merge = pd.DataFrame()
    
    for corp in corp_list:
        corp_df = get_corp_whynot_report(db,corp)
        changes = []
        previous_prices = []
        previous = None
        for i, row in corp_df.iterrows():
            if previous is None or row['애널'] != previous['애널'] or previous['목표가'] in [0, 'NR']:
                changes.append('No prior data')  # No prior data for this analyst
                previous_prices.append(None)
            else:
                changes.append(classify_change(row, previous))
                previous_prices.append(previous['목표가'])  # 이전 목표가 저장
            previous = row

        corp_df['목표가_변동'] = changes
        corp_df['이전목표가'] = previous_prices  # 이전목표가 컬럼 추가
        daily_merge = pd.concat([daily_merge,corp_df])
        
    biz_day = pd.to_datetime(biz_day).date()
    increased_df = daily_merge[(daily_merge['목표가_변동'] == 'Increased') & (daily_merge['기준일'] == biz_day)]
    increased_df['이전목표가'] = increased_df['이전목표가'].astype(int)
    increased_df['목표가'] = increased_df['목표가'].astype(int)
    increased_df['상향률'] = round((increased_df['목표가'] - increased_df['이전목표가'])/increased_df['이전목표가']*100,1)
    # increased_df = increased_df[['기준일','종목명','애널','목표가','이전목표가','상향률','판단','제목','내용','목표가_변동']]
    
    increased_df = increased_df.merge(price,how='left')
    
    increased_df['괴리률'] = round((increased_df['목표가']-increased_df['종가'])/increased_df['종가']*100,1)
    increased_df = increased_df[['기준일','종목명','애널','괴리률','등락률','종가','목표가','이전목표가','상향률','판단','제목','내용','목표가_변동']]

    save(increased_df)    
    print(f'종목수 : {len(final)}, 상향레폿:{len(increased_df)}')
        