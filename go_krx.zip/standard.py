import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day
import matplotlib.pyplot as plt


def get_merge(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT kta.기준일 , kta.종목코드 ,kta.종목명 ,kta.투신,kta.사모,kta.연기금등,
			ROUND( kta.금융투자 + kta.보험 + kta.투신+kta.사모+kta.은행+kta.연기금등) AS 기관 ,
			kta.외국인,kta.개인,kdp.거래량,kdp.거래대금 ,kdp.시가총액 ,kdp.등락률,st.산업_대
        FROM krx_trade_amount kta
        LEFT	JOIN krx_daily_price kdp 
                ON kta.기준일 = kdp.기준일 
                AND kta.종목명 = kdp.종목명
        LEFT	JOIN sector st 
                ON kdp.종목명 = st.종목명
        WHERE kta.기준일 = '{biz_day}';
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','종목코드','종목명','투신','사모','연기금','기관','외국인','개인','거래량','거래대금','시가총액','등락률','그룹'])
    df = df.sort_values(['종목명','기준일'],ascending=False)
    df['그룹'] = df.groupby('종목명')['그룹'].fillna(method='ffill')
  
    
    # filtered_stocks = recent_3days_data.groupby('종목코드').filter(
    # lambda x: all(x['투신'] > 1.0) or all(x['사모'] > 1.0) or all(x['연기금'] > 1.0)

    # grouped_data = df.groupby(['기준일', '그룹'])['기관'].sum().reset_index()
    # kospi_prices = df[df['지수명'] == '코스피'][['기준일', '종가']].drop_duplicates()
    # merged_data = pd.merge(grouped_data, kospi_prices, on='기준일', how='left')
    # pivot_df = merged_data.pivot_table(index=['기준일', '종가'],columns='그룹', values='기관',aggfunc='sum').reset_index()
    return df
    
def save(final):
    file_name = './trading_amount/거래대금.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    final.to_excel(
        writer, 
        sheet_name='Sheet1',
        startcol = 0,
        startrow = writer.sheets['Sheet1'].max_row,
        index=False, 
        na_rep = '',      # 결측값을 ''으로 채우기
        inf_rep = '',     # 무한값을 ''으로 채우기
        header = None
        )
    writer.close()
    
from datetime import datetime, timedelta        
if __name__ == '__main__':
    biz = working_day()
    db = connDB.db_conn()
    # biz = '20241107'


    final = get_merge(db,biz)
    save(final)

        
#      from datetime import datetime, timedelta

    # start_date = datetime.strptime('20240725', '%Y%m%d')
    # end_date = datetime.strptime('2024831', '%Y%m%d')
    # date_list = [(start_date + timedelta(days=x)).strftime('%Y%m%d') for x in range((end_date - start_date).days + 1)]

    # for biz in date_list:
    #     print(biz)
    #     try:
    #             final = get_merge(db, biz)
    #             save(final)
    #     except:
    #             pass