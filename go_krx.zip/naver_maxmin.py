import requests
import pandas as pd
import pymysql
from bs4 import BeautifulSoup
import numpy as np
import re
import time
from day import working_day
import json



def naver_maxmin(biz,code,name):
    lists = []
    url = f'https://finance.naver.com/item/main.naver?code={code}'
    res  = requests.get(url)
    soup = BeautifulSoup(res.text,'html.parser')
    cur = soup.select_one('div.sub_section.right > table.tb_type1 > tbody > tr:nth-of-type(2) > td > em').text
    max = soup.select_one('table.rwidth tr:nth-of-type(2) > td > em:nth-of-type(1)').text
    min = soup.select_one('table.rwidth tr:nth-of-type(2) > td > em:nth-of-type(2)').text
    lists.append([cur,max,min])
    df = pd.DataFrame(lists,columns=['현재가','52최고가','52최저가'])
    df = df.apply(lambda x : x.str.replace(',','').astype(int))
    df['신고가율'] = round((df['현재가']/df['52최고가'])*100,1)
    df['갭'] = round((df['52최고가']/df['52최저가'])*100,1)
    df.insert(0,'종목명',name)
    df.insert(0,'기준일',biz)
    return df

def corp_list():
    lists = []
    url = f'https://comp.fnguide.com/XML/Market/CompanyList.txt'
    res  = requests.get(url)
    decoded_content = res.content.decode('utf-8-sig')
    data = json.loads(decoded_content)
    datas = data['Co']
    for data in datas:
        if data['gb'] == '701':
            data['cd'] = data['cd'][1:] 
            lists.append([data['cd'],data['nm']])
    return lists

def save(final):
    file_name = './naver_maxmin/신고가.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    final.to_excel(
        writer, 
        sheet_name='Sheet1',
        startcol = 0,
        startrow = writer.sheets['Sheet1'].max_row,
        index=False, 
        na_rep = '',      # 결측값을 ''으로 채우기
        inf_rep = '',     # 무한값을 ''으로 채우기
        header = None
        )
    writer.close()





if __name__ == '__main__':
    biz = working_day()
    corplists=corp_list()
    filtered_corplists = [item for item in corplists if '스팩' not in item[1]]
    df = pd.DataFrame()
    for code,name in filtered_corplists:
        try:
            dd = naver_maxmin(biz,code,name)
            df = pd.concat([df,dd])
        except Exception as e:
            print(name,e)
    df.to_clipboard()
    save(df)
    print(df)