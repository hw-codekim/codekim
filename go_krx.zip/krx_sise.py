import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day

def get_kospi(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT * FROM krx_sise
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','지수명','종가','대비','등락률','시가','고가','저가','거래량','거래대금','시총'])
    df['기준일'] = pd.to_datetime(df['기준일']).dt.strftime('%Y-%m-%d')
    kospi = df[df['지수명'] == '코스피']
    kosdaq = df[df['지수명'] == '코스닥']
    kospi_big = df[df['지수명'] == '코스피대형주']
    kospi_mid = df[df['지수명'] == '코스피중형주']
    kospi_sml = df[df['지수명'] == '코스피소형주']
    kosdaq_big = df[df['지수명'] == '코스닥대형주']
    kosdaq_mid = df[df['지수명'] == '코스닥중형주']
    kosdaq_sml = df[df['지수명'] == '코스닥소형주']
    
    kospi['변동폭'] = kospi['종가'].diff()
    kospi["상승폭"] = kospi["변동폭"].apply(lambda x: x if x > 0 else 0)
    kospi["하락폭"] = kospi["변동폭"].apply(lambda x: -x if x < 0 else 0)
    # 14일 평균 상승 및 하락폭 계산
    kospi["평균상승폭"] = kospi["상승폭"].rolling(window=14, min_periods=1).mean()
    kospi["평균하락폭"] = kospi["하락폭"].rolling(window=14, min_periods=1).mean()

    # RSI 계산
    kospi["RSI"] = 100 - (100 / (1 + (kospi["평균상승폭"] / kospi["평균하락폭"])))
    kospi = kospi[['기준일','지수명','종가','대비','등락률','시가','고가','저가','거래량','거래대금','시총','RSI']]
    
    
    kosdaq['변동폭'] = kosdaq['종가'].diff()
    kosdaq["상승폭"] = kosdaq["변동폭"].apply(lambda x: x if x > 0 else 0)
    kosdaq["하락폭"] = kosdaq["변동폭"].apply(lambda x: -x if x < 0 else 0)
    # 14일 평균 상승 및 하락폭 계산
    kosdaq["평균상승폭"] = kosdaq["상승폭"].rolling(window=14, min_periods=1).mean()
    kosdaq["평균하락폭"] = kosdaq["하락폭"].rolling(window=14, min_periods=1).mean()

    # RSI 계산
    kosdaq["RSI"] = 100 - (100 / (1 + (kosdaq["평균상승폭"] / kosdaq["평균하락폭"])))
    kosdaq = kosdaq[['기준일','지수명','종가','대비','등락률','시가','고가','저가','거래량','거래대금','시총','RSI']]
    
    kospi = kospi[kospi['기준일'] == biz_day]
    kosdaq = kosdaq[kosdaq['기준일'] == biz_day]
    kospi_big = kospi_big[kospi_big['기준일'] == biz_day]
    kospi_mid = kospi_mid[kospi_mid['기준일'] == biz_day]
    kospi_sml = kospi_sml[kospi_sml['기준일'] == biz_day]
    kosdaq_big = kosdaq_big[kosdaq_big['기준일'] == biz_day]
    kosdaq_mid = kosdaq_mid[kosdaq_mid['기준일'] == biz_day]
    kosdaq_sml = kosdaq_sml[kosdaq_sml['기준일'] == biz_day]
    
    return kospi,kosdaq,kospi_big,kospi_mid,kospi_sml,kosdaq_big,kosdaq_mid,kosdaq_sml

def save(kospi,kosdaq,kospi_big,kospi_mid,kospi_sml,kosdaq_big,kosdaq_mid,kosdaq_sml):
    file_name = './krx_sise/종합지수.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    
    datas = [kospi,kosdaq,kospi_big,kospi_mid,kospi_sml,kosdaq_big,kosdaq_mid,kosdaq_sml]
    shees_names = ['코스피','코스닥','코스피대형주','코스피중형주','코스피소형주','코스닥대형주','코스닥중형주','코스닥소형주']
    for data,sheet_name in zip(datas,shees_names):
        data.to_excel(
            writer, 
            sheet_name=sheet_name,
            startcol = 0,
            startrow = writer.sheets[sheet_name].max_row,
            index=False, 
            na_rep = '',      # 결측값을 ''으로 채우기
            inf_rep = '',     # 무한값을 ''으로 채우기
            header = None
            )
    writer.close()


if __name__ == '__main__':
    date = working_day()
    db = connDB.db_conn()
    biz_day = working_day()
    biz_day = pd.to_datetime(biz_day).strftime('%Y-%m-%d')
    # biz_day='2024-11-26'
    
    sise_df = get_kospi(db,biz_day)
    kospi = sise_df[0]
    kosdaq = sise_df[1]
    kospi_big = sise_df[2]
    kospi_mid = sise_df[3]
    kospi_sml = sise_df[4]
    kosdaq_big = sise_df[5]
    kosdaq_mid = sise_df[6]
    kosdaq_sml = sise_df[7]
    # print(kospi,kosdaq,kospi_big,kospi_mid,kospi_sml,kosdaq_big,kosdaq_mid,kosdaq_sml)
    save(kospi,kosdaq,kospi_big,kospi_mid,kospi_sml,kosdaq_big,kosdaq_mid,kosdaq_sml)
    
    