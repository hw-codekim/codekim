import pymysql
import numpy as np
import warnings
from key.db_info import connDB
import pandas as pd
from day import working_day

def get_naver_group(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        SELECT ng.*, 
        kdp.시가총액, kdp.시장구분,
        ROUND((ng.거래량 - ng.전일거래량) / ng.전일거래량 * 100, 0) AS 거래량변동률,
        ROUND(ng.거래대금 / kdp.시가총액, 2) AS 거래시총비율
        FROM naver_group ng
        LEFT JOIN krx_daily_price kdp 
            ON ng.기준일 = kdp.기준일 
            AND ng.종목명 = kdp.종목명
        WHERE ng.거래대금 > 100
        AND ng.기준일 = '{biz_day}'
        AND kdp.시가총액 > '800'
        AND ng. 등락률 > '5'
        AND kdp.시장구분 != 'KONEX'
        AND ng.현재가 > 500
        AND ROUND((ng.거래량 - ng.전일거래량) / ng.전일거래량 * 100, 0) > 100
        ORDER BY 거래시총비율 DESC;;
        """
        # AND ROUND(ng.거래대금 / kdp.시가총액, 2) >= 0.1
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['기준일','그룹','종목명','현재가','등락률','거래량','거래대금','전일거래량','시가총액','시장구분','거래변동률','거래시총비율'])
    df = df[['기준일','그룹','종목명','현재가','등락률','거래량','거래대금','전일거래량','시가총액','거래변동률','거래시총비율']]
    # df = df['거래변동율'].astype(float)
    
    return df

def get_google_news(db,biz_day):
    con = pymysql.connect(
            user=db[0],
            password=db[1],
            host = db[2],
            port = int(db[3]),
            database=db[4],                     
            )
    mycursor = con.cursor()
    sql = f"""
        select * from google_stocknews gs 
        where 1=1
        and 기준일 = '{biz_day}';
        """
    mycursor.execute(sql)
    result = mycursor.fetchall()
    con.close()
    df = pd.DataFrame(result,columns=['종목명','기준일','제목','링크'])
    df['제목'] = df['제목'].str.replace('"', '')
    # df['제목1'] = df.apply(lambda row: f'=HYPERLINK("{row["링크"]}", "{row["제목"]}")', axis=1)
    # df['엑셀_하이퍼링크'] = df.apply(lambda row: f'=HYPERLINK("{row["링크"]}", "{row["제목"]}")', axis=1)
    df = df[['종목명','기준일','제목','링크']]
    return df

def save(final):
    file_name = './naver_group/거래변동률상위.xlsx'
    writer = pd.ExcelWriter(file_name, mode='a', engine='openpyxl', if_sheet_exists='overlay')
    final.to_excel(
        writer, 
        sheet_name='Sheet1',
        startcol = 0,
        startrow = writer.sheets['Sheet1'].max_row,
        index=False, 
        na_rep = '',      # 결측값을 ''으로 채우기
        inf_rep = '',     # 무한값을 ''으로 채우기
        header = None
        )
    writer.close()




if __name__ == '__main__':
    date = working_day()
    db = connDB.db_conn()
    biz_day = working_day()
    # biz_day = '20241029'

 
    final = get_naver_group(db,biz_day)
    news = get_google_news(db,biz_day)

    final_df = final.merge(news,how='left')
    # final_df.to_clipboard()

    save(final_df)
    