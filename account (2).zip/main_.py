import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import uic
from PyQt5.QtGui import QBrush, QColor

from loaded_data.baseCode import BaseCode
from loaded_data.stock_inform import stock_info
from biz_day import Bizday

import csv

# form_class = uic.loadUiType("account_management.ui")[0]

class WindowClass(QMainWindow) :
    def __init__(self) :
        super().__init__()
        # self.setupUi(self)
        self.ui = uic.loadUi("account_management.ui", self)  # setupUi 대체
        self.btn_changeText.clicked.connect(self.on_button_1)
        
        # 날짜
        self.default_date = Bizday.biz_day() 
        self.dateEdit.setDate(QDate.fromString(self.default_date, 'yyyyMMdd'))
        
        # 초기 테이블 설정
        self.boyoutableWidget.setRowCount(0)  # 초기에는 행이 없도록 설정
        self.boyoutableWidget.setColumnCount(18)  # 열 수는 3으로 설정 (예: StockName, StockCount, Price)
        self.boyoutableWidget.setHorizontalHeaderLabels(['계좌','매매','매수일','섹터','종목코드',"종목명", "매수가", "매수수량",'매수금액',
                                                        "현재가","수익금","수익률",'평가금액',"비중","매도가","매도수량","보유일",'체크'])
        self.boyoutableWidget.verticalHeader().setDefaultSectionSize(22)# 컬럼 높이 22로 
        # self.boyoutableWidget.resizeColumnsToContents()
        
        #저장로더버튼
        self.saveButton.clicked.connect(self.saveTableToCSV)
        self.loadButton.clicked.connect(self.loadCSVToTable)
        
    def on_button_1(self):
        self.acctableWidget()
    
    def acctableWidget(self):
        
        # QLineEdit에서 텍스트 가져오기
        account = self.accountcomboBox.currentText()
        judge = self.judgecomboBox.currentText()
        date = self.dateEdit.date().toString('yyyy-MM-dd')
        sector = self.sectorlineEdit.text()
        # code = self.codelineEdit.text()
        name = self.namelineEdit.text()
        price = self.pricelineEdit.text() #매수단가
        cnt = self.cntlineEdit.text() #매수수량
        rst_code = BaseCode.base_info(name)[1] #종목명을 넣으면 코드를 반환한다.
        cur_price = stock_info(rst_code).iloc[0,1] # 현재가
        
        
        if price == '' or cnt == '':
            # price 또는 cnt가 비어있으면 계산하지 않고 다음으로 넘어감
            cal_price = '0'
        else:
            cal_price = int(price) * int(cnt)  # 매수총액
            profit_price = int(cur_price.replace(',',''))*int(cnt)-cal_price # 수익금 (현재가-매수가)
            profit_rate = round(profit_price/cal_price*100,1)#수익률(현재가-매수가/매수가)
            current_cal_price = int(cur_price.replace(',',''))*int(cnt)
        
        # #비중계산
        # total_investment = 0
        # for row in range(self.boyoutableWidget.rowCount()):
        #     print(row)
        #     cell_value = self.boyoutableWidget.item(row, 12)  # 'current_cal_price' 컬럼 인덱스
        #     print(cell_value,'88')
        #     if cell_value:
        #         print('11111')
        #         total_investment += int(cell_value.text())
        
        # # 현재 행의 비중 계산
        # if total_investment > 0:
        #     weight = (int(current_cal_price) / total_investment) * 100
        # else:
        #     weight = 0
        
        
        
        # # 날짜 계산
        # user_date = QDate.fromString(date, 'yyyy-MM-dd')  # 사용자 선택 날짜를 QDate로 변환
        # date_diff = self.default_date.daysTo(user_date)  # 날짜 차이 계산        
        
        # 테이블에 새 행 추가
        currentRowCount = self.boyoutableWidget.rowCount()  # 현재 행 수 가져오기
        self.boyoutableWidget.insertRow(currentRowCount)  # 새로운 행 추가
        
        items = [
            account, judge, date, sector, rst_code, name, 
            price, cnt, str(cal_price), cur_price, 
            str(profit_price), str(profit_rate),str(current_cal_price)
        ]
        # 열 너비 설정
        column_widths = [80, 70, 80, 70, 60, 80, 70, 70, 80, 70, 80, 60]
        
        for col, text in enumerate(items):
            item = QTableWidgetItem(text)
            # item = QTableWidgetItem(f"{text:.2f}%")
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            item.setBackground(QBrush(QColor("white")))
            self.boyoutableWidget.setItem(currentRowCount, col, item)
            
        for col, width in enumerate(column_widths):
            self.boyoutableWidget.setColumnWidth(col, width)
        
        # 컬럼 너비 자동 조정
        self.boyoutableWidget.resizeColumnsToContents()

        
        # 삭제 버튼 추가
        deleteButton = QPushButton("삭제")
        deleteButton.clicked.connect(lambda: self.deleteRow(deleteButton))
        self.boyoutableWidget.setCellWidget(currentRowCount, 17, deleteButton)
        
    def saveTableToCSV(self):
        # 파일명을 고정: '보유종목.CSV'
        filePath = "보유종목.CSV"
        
        try:
            # UTF-8 with BOM 인코딩으로 파일 저장
            with open(filePath, mode='w', newline='', encoding='utf-8-sig') as file:
                writer = csv.writer(file)
                
                # 헤더 작성
                headers = [self.boyoutableWidget.horizontalHeaderItem(col).text() for col in range(self.boyoutableWidget.columnCount())]
                writer.writerow(headers)
                
                # 데이터 작성
                for row in range(self.boyoutableWidget.rowCount()):
                    row_data = []
                    for col in range(self.boyoutableWidget.columnCount()):
                        cell_item = self.boyoutableWidget.item(row, col)
                        if cell_item:
                            cell_text = cell_item.text()
                            if col == 4:  # CSV의 5번째 컬럼
                                cell_text = f"'{cell_text}"  # 앞에 작은 따옴표를 추가하여 0 보존
                            row_data.append(cell_text)
                        else:
                            row_data.append("")
                    writer.writerow(row_data)
            
            print(f"Table saved successfully to {filePath}")
        except Exception as e:
            print(f"Error saving table to CSV: {e}")
            
            
    def loadCSVToTable(self):
        # 파일명을 고정: '보유종목.CSV'
        filePath = "보유종목.CSV"
        
        try:
            with open(filePath, mode='r', encoding='utf-8-sig') as file:
                reader = csv.reader(file)
                
                # 기존 테이블 데이터 초기화
                self.boyoutableWidget.clear()
                
                # 헤더 설정
                headers = next(reader)  # 첫 번째 행은 헤더
                self.boyoutableWidget.setColumnCount(len(headers))
                self.boyoutableWidget.setHorizontalHeaderLabels(headers)
                
                # 데이터 추가
                self.boyoutableWidget.setRowCount(0)  # 기존 행 초기화
                for row_data in reader:
                    currentRowCount = self.boyoutableWidget.rowCount()
                    self.boyoutableWidget.insertRow(currentRowCount)
                    r_code = row_data[4].zfill(6)[1:]  # 6자리로 맞춤, [1:] 앞에 저장할때 작은따옴표 생성, 불러 올때 제거
                    row_data[4] = r_code
                    
                    # stock_info를 통해 현재가 가져오기
                    try:
                        cur_price = stock_info(r_code).iloc[0, 1]  # 현재가 가져오기
                    except Exception as e:
                        cur_price = "N/A"  # 오류 시 기본값
                    
                    # row_data[9]에 현재가 값을 넣음 (strip()을 통해 공백 제거)
                    row_data[9] = str(cur_price).strip()
                    cur_price_int = int(row_data[9].replace(',', '').strip()) # 현재가 쉼표 제거
                    cur_cnt_int = int(row_data[7].replace(',', '').strip()) # 수량 쉼표 제거
                    cur_cal_int = int(row_data[8].replace(',', '').strip()) # 매수금액 쉼표 제거
                    
                    
                    r_profit_price = cur_price_int*cur_cnt_int-cur_cal_int # r_.. 재계산 수익금
                    r_profit_rate = round(r_profit_price/cur_cal_int*100,1)

                    # row_data[8]=str(cur_cal_int)
                    row_data[10]=str(r_profit_price)
                    row_data[11]=str(r_profit_rate)

                    for col, data in enumerate(row_data):

                        item = QTableWidgetItem(data)
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        # 배경 색을 하얀색으로 설정
                        item.setBackground(Qt.white)
                        
                        if col in [6, 7, 8, 10, 12]:  # 매수가(6), 매수수량(7), 매수금액(8), 수익금(10), 평가금액(12)
                            try:
                                value = float(data.replace(',', ''))  # 쉼표를 제거하고 숫자로 변환
                                item.setText(f"{value:,.0f}")  # 천의 자리 쉼표 추가
                            except ValueError:
                                pass  # 숫자로 변환할 수 없는 경우는 그대로 유지

                        # 수익금, 수익률에 따라 글자 색 변경
                        if col == 10:  # 수익금 (11번째 컬럼)
                            try:
                                profit = float(data.replace(',', ''))
                                if profit > 0:
                                    item.setForeground(Qt.red)  # 빨간색
                                elif profit < 0:
                                    item.setForeground(Qt.blue)  # 파란색
                                else:
                                    item.setForeground(Qt.black)  # 검은색
                            except ValueError:
                                item.setForeground(Qt.black)  # 수익금이 잘못된 값일 경우 기본값 검은색
                        elif col == 11:  # 수익률 (12번째 컬럼)
                            try:
                                rate = float(data.replace(',', ''))
                                if rate > 0:
                                    item.setForeground(Qt.red)  # 빨간색
                                elif rate < 0:
                                    item.setForeground(Qt.blue)  # 파란색
                                else:
                                    item.setForeground(Qt.black)  # 검은색
                            except ValueError:
                                item.setForeground(Qt.black)  # 수익률이 잘못된 값일 경우 기본값 검은색
                        
                        self.boyoutableWidget.setItem(currentRowCount, col, item)
                        self.boyoutableWidget.resizeColumnsToContents() # 컬럼 자동장렬
                        
            print(f"Table loaded successfully from {filePath}")
        except FileNotFoundError:
            print(f"{filePath} not found. Please ensure the file exists.")
        except Exception as e:
            print(f"Error loading CSV to table: {e}")
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = WindowClass()
    window.show()
    sys.exit(app.exec_())