import plotly.graph_objects as go
import time
from datetime import datetime
from loaded_data.krx_sise import SiseTrade
from loaded_data.baseCode import BaseCode
from biz_day import Bizday


def Stock_Chart(df_stock):
    df_stock['MA5'] = df_stock['종가'].rolling(window=5).mean()
    df_stock['MA10'] = df_stock['종가'].rolling(window=10).mean()
    df_stock['MA20'] = df_stock['종가'].rolling(window=20).mean()
    df_stock['MA60'] = df_stock['종가'].rolling(window=60).mean()
    df_stock = df_stock.reset_index()
    df_stock['일자'] = df_stock['일자'].apply(lambda x : datetime.strftime(x, '%Y-%m-%d')) # Datetime to str

    # df_stock = df_stock.reset_index()
    # st.write(df_stock)
    # df_stock = df_stock[df_stock.index.weekday < 5]

    # df_stock['Date'] = df_stock['Date'].strftime('%Y-%m-%d')

    # Define holidays (example)
    # holidays = ['2024-02-09', '2024-02-12', '2024-03-01', '2024-05-06', '2024-05-15', '2024-06-06']  # Add your actual holiday dates
    # holidays = pd.to_datetime(holidays)
    # df_stock = df_stock[~df_stock.index.isin(holidays)]



    fig = go.Figure()
    fig.add_trace(go.Candlestick(
    x=df_stock['Date'],
    open=df_stock['시가'],
    high=df_stock['고가'],
    low=df_stock['저가'],
    close=df_stock['종가'],
    increasing_line_color='green', 
    decreasing_line_color='red',
    increasing_line_width=0.5,  # Set the line width for increasing candles
    decreasing_line_width=0.5,  # Set the line width for decreasing candles
    name='Candlestick'))

    fig.add_trace(go.Scatter(x=df_stock['Date'], y=df_stock['MA5'], mode='lines', name='MA5', line=dict(color='blue')))
    fig.add_trace(go.Scatter(x=df_stock['Date'], y=df_stock['MA20'], mode='lines', name='MA20', line=dict(color='purple')))
    # fig.add_trace(go.Scatter(x=df_stock['Date'], y=df_stock['MA60'], mode='lines', name='MA60', line=dict(color='red')))


    fig.update_layout(
    title='Stock Price Candlestick Chart 2024.01.01~',
    xaxis_title='Date',
    yaxis_title='Price',
    xaxis_rangeslider_visible=False,
    xaxis=dict(
        tickmode='linear',
        dtick='30',
        # tickformat='%Y-%m-%d',
        tickangle=0,
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGray',
        type='category',
        categoryorder='category ascending'
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='LightGray',
        tickformat=',.0f'  # Remove the 'k' format and show full numbers
    ),
    template='plotly_white',
    margin=dict(l=10, r=10, t=30, b=20)
    )
    fig.update_xaxes(title=None)
    fig.update_yaxes(title=None)

    fig.show()
    
if __name__ == '__main__':
    day = Bizday.biz_day()
    strtDd = '20240102'
    endDd = day
    stockName = 'DS단석'
    stCode,stockCode = BaseCode.base_info(stockName)
    # df = SiseTrade.corp_trading(endDd,stockName,stCode,stockCode)
    sise_df = SiseTrade.corp_sise(endDd,stockName,stCode,stockCode)
    Stock_Chart(sise_df)