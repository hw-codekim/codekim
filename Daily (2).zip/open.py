import pandas as pd
import numpy as np
from biz_day import Bizday
import os
import holidays
from pandas.tseries.offsets import CustomBusinessDay
from tqdm import tqdm

class Merge_CSV:
    def sort_data(price,money,sise):
        
        price = price.sort_values(by=['종목명','날짜'],ascending=True)
        
        price['전일종가'] = price.groupby('종목명')['종가'].shift(1)
        price['갭'] = np.round((price['시가'] - price['전일종가'])/price['전일종가'] * 100,1)
        price['시총대비거래'] = np.round(price['거래대금']/price['시가총액'] * 100,0)
        price['종가MA5'] = price.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=5).mean().round(0))
        price['종가MA50'] = price.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=50).mean().round(0))
        # price['종가UP20'] = np.where(price['종가MA5'] > price['종가MA20'], 1, 0) # 케이스 1 5일선이 20일선 위에 있을때
        price['종가UP50_Shift'] = price.groupby('종목명')['종가MA50'].shift(1)
        # price['selected'] = price[(price['종가MA5'] > price['종가MA50']) & (price['종가MA50'] < price['종가UP50_Shift'])]
        
        # price['거래MA5'] = price.groupby('종목명')['거래량'].transform(lambda x: x.rolling(window=5).mean().round(0))
        # price['거래MA20'] = price.groupby('종목명')['거래량'].transform(lambda x: x.rolling(window=10).mean().round(0))
        # price['거래UP20'] = np.where(price['거래량']/price['거래MA20'] > 2.0, 1, 0)
        
        # price['고가10일max'] = price.groupby('종목명')['고가'].transform(lambda x: x.iloc[-10:].max() if len(x) >= 10 else x.max())
        # price['고가10일max_'] = np.where(price['고가10일max'] <= price['종가'], 1, 0) 
        # price['MDD'] = round(((price['종가'] - price['고가10일max'])/ price['종가']) * 100,1) # 케이스 2 MDD -10% 이하
        
        # price['거래max'] = price.groupby('종목명')['거래량'].transform(lambda x: x.iloc[-10:].max() if len(x) >= 10 else x.max())
        # price['거래10일max_'] = round(price['거래max']/price['거래MA10'] * 100,1)  # 케이스 3 
        
        money = money.sort_values(by=['종목명','날짜'],ascending=True)

        money['기관합계'] = money['사모'] + money['연기금']+money['투신']
        money['기관MA20'] = money.groupby('종목명')['기관합계'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['개인MA20'] = money.groupby('종목명')['개인'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['금융MA20'] = money.groupby('종목명')['금융투자'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['사모MA20'] = money.groupby('종목명')['사모'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['연기금MA20'] = money.groupby('종목명')['연기금'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['외국인MA20'] = money.groupby('종목명')['외국인'].transform(lambda x: x.rolling(window=5).mean().round(0))
        money['투신MA20'] = money.groupby('종목명')['투신'].transform(lambda x: x.rolling(window=5).mean().round(0))


        sise = sise.sort_values(by='날짜',ascending=True)
        sise['코스피MA20'] = sise['코스피'].rolling(window=5).mean().round(0)
        sise['코스닥MA20'] = sise['코스닥'].rolling(window=5).mean().round(0)
        
        m_df = pd.merge(left = price,right = money,how='left',on=['종목명','날짜'],sort=False)
        m_df = m_df.dropna()
        
        s_df = pd.merge(left = m_df,right = sise,how='left',on='날짜',sort=False)
        return s_df

    def trading_(df,bizDay):
        today = df[df['날짜'] == int(bizDay)]
        # rst = today[(today['거래UP20'] == 1) & (today['등락률'] > 3) & (today['거래대금'] > 20) & ((today['사모'] > 1) | (today['투신'] > 1)|(today['연기금'] > 1))]
        rst = today[(today['종가MA5'] > today['종가MA50']) & (today['종가MA50'] < today['종가UP50_Shift'])& (today['종가'] > today['종가MA50'])]
        rst = rst.sort_values(by='등락률',ascending=False)
        rst = rst[['날짜','종목명','종가','등락률','거래대금','시가총액','시총대비거래','종가MA5','종가MA50','종가UP50_Shift','사모','투신','연기금','외국인','금융투자','개인']]
        return rst

    def save(selected_df): # 엑셀 저장
        try:
            if not os.path.exists(f'종목발굴_{bizDay}.csv'):
                selected_df.to_csv(f'종목발굴_{bizDay}.csv', mode='w', encoding='utf-8-sig' ,index=False)
            else:
                selected_df.to_csv(f'종목발굴_{bizDay}.csv', mode='a', encoding='utf-8-sig', header=False,index=False)
        except Exception as e:
            print(e)
        finally:    
            print(f"종목발굴 파일이 저장되었습니다")

    def corp_analysis(df,name):
        result = df[df['종목명'] == name]
        
        return result 





if __name__ == '__main__':
    bizDay = Bizday.biz_day()

    money = pd.read_csv('거래대금.csv')
    price = pd.read_csv('종목별20일선.csv')
    sise = pd.read_csv('지수.csv')
    
    df = Merge_CSV.sort_data(price,money,sise)
    # dd = Merge_CSV.trading_(df,bizDay)
    # df.to_clipboard()
    # print(df)
    
    
    # ================== 개별기업 확인할때
    # name = '알테오젠'
    # co = Merge_CSV.corp_analysis(df,name) #개별 주식
    # co.to_clipboard()
    
    # =================== 여러개 구할때
    inp = 1
    selected_df = pd.DataFrame()
    for i in tqdm(range(inp)):
        start_date = pd.to_datetime(bizDay)
                    
        # 한국 공휴일 가져오기
        kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
        holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

        # CustomBusinessDay 설정
        kr_business_day = CustomBusinessDay(holidays=holidays_list)
        five_days_before = start_date - (i * kr_business_day)
        start_day = five_days_before.strftime('%Y%m%d')
        dd = Merge_CSV.trading_(df,start_day)
        selected_df = pd.concat([selected_df,dd])
    # selected_df.to_clipboard()
    Merge_CSV.save(selected_df)



