import requests
from bs4 import BeautifulSoup
import re
from io import BytesIO
import pandas as pd
import numpy as np
import time
import re
from datetime import datetime,timedelta
import collections
from tqdm import tqdm
import os


class Krx_daily_price:
    
    # if not hasattr(collections, 'Callable'):
    #     collections.Callable = collections.abc.Callable
    
    # def biz_day(): # 네이버에서 날짜가져오기
    #     url = 'https://finance.naver.com/sise/sise_index.naver?code=KOSPI'
    #     res = requests.get(url)
    #     soup = BeautifulSoup(res.text,'html.parser')

    #     parse_day = soup.select_one('#time').text
        
    #     biz_day = re.findall('[0-9]+',parse_day)
    #     biz_day = ''.join(biz_day)
    #     return biz_day

    def daily_price(biz_day):
        gen_otp_url = 'http://data.krx.co.kr/comm/fileDn/GenerateOTP/generate.cmd'
        gen_otp = {
            'locale': 'ko_KR',
            'mktId': 'ALL',
            'trdDd': biz_day,
            'share': '1',
            'money': '1',
            'csvxls_isNo': 'false',
            'name': 'fileDown',
            'url': 'dbms/MDC/STAT/standard/MDCSTAT01501'
            }

        headers = {
                'Referer':'http://data.krx.co.kr/contents/MDC/MDI/mdiLoader/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
                }

        otp_stk = requests.post(gen_otp_url,gen_otp,headers=headers).text

        down_url = 'http://data.krx.co.kr/comm/fileDn/download_csv/download.cmd'
        down = requests.post(down_url, {'code':otp_stk}, headers=headers)
        daily_updown = pd.read_csv(BytesIO(down.content), encoding='EUC-KR')
        
        daily_updown['시가총액'] = round(daily_updown['시가총액']/100000000,0)
        daily_updown['거래대금'] = round(daily_updown['거래대금']/100000000,1)
        daily_updown = daily_updown.replace({np.nan:None})
        daily_updown['종목명'] = daily_updown['종목명'].str.strip()
        daily_updown.insert(0,'기준일',biz_day)
        daily_updown = daily_updown[
                        (daily_updown['시장구분'] != 'KONEX') &
                        (~daily_updown['종목명'].str.endswith('우')) &
                        (~daily_updown['소속부'].str.contains('SPAC', na=False)) &
                        (~daily_updown['소속부'].str.contains('관리', na=False))
                        ]
        print(f'[{biz_day}] 종목 {len(daily_updown)}개 로딩 성공')
        time.sleep(2)
        return daily_updown

    def save(df): # 엑셀 저장
        try:
            df = df.dropna(subset=['종가'])
            df = df[df['저가'] != 0]
            df['종가'] = df['종가'].astype(float)
            df['저가'] = df['저가'].astype(float)
            df['고가'] = df['고가'].astype(float)
            df['시가'] = df['시가'].astype(float)
            df = df.sort_values(by=['종목명','기준일'],ascending=True)
            df['아랫꼬리'] = round((df['종가'] - df['저가']) / df['저가'] * 100,1)
            df['윗꼬리'] = np.round((df['종가'] - df['고가'])/df['고가'] * 100,1)
            # df['전일종가'] = df.groupby('종목명')['종가'].shift(1)
            # df['갭'] = np.round((df['시가'] - df['전일종가'])/df['전일종가'] * 100,1)
            # df['종가MA20'] = df.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=20).mean().round(0))
            # df['종가UP20'] = np.where(df['종가'] > df['종가MA20'], 1, 0)
            # df['거래MA20'] = df.groupby('종목명')['거래량'].transform(lambda x: x.rolling(window=20).mean().round(0))
            # df['거래UP20'] = np.where(df['거래량']/df['거래MA20'] > 2.0, 1, 0)
            df = df[['기준일','종목명','종가', '등락률', '시가', '고가','저가', '거래량', '거래대금', '시가총액','아랫꼬리',
                    '윗꼬리']]#, '전일종가', '갭','종가MA20', '종가UP20', '거래MA20', '거래UP20']]
            
            if not os.path.exists('종목별20일선.csv'):
                df.to_csv('종목별20일선.csv', mode='w', encoding='utf-8-sig')
            else:
                df.to_csv('종목별20일선.csv', mode='a', encoding='utf-8-sig', header=False)
            
            
            
            
            # df.to_csv(f'종목별20일선_{end_day}.csv', index=False, na_rep='',encoding='utf-8-sig')
        except Exception as e:
            print(e)
        finally:    
            print(f"20일가격 파일이 저장되었습니다")
        
# if __name__ == '__main__':
#     end_day = krx_daily_price.biz_day()
#     inp=int(input('조회기간 입력해주세요 : '))  

#     df = pd.DataFrame()
#     for i in tqdm(range(inp)):
#         try:
#             start_date = pd.to_datetime(end_day)
#             start_day = start_date - timedelta(days=i)  
#             start_day = start_day.strftime('%Y%m%d')
#             result_df = krx_daily_price.daily_price(start_day)
#             df = pd.concat([df,result_df])
#         except Exception as e:
#             print(e)
#     krx_daily_price.save(df)

