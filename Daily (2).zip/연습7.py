# ML 모델링위한 Labeling 방법론, 상단에 부딪히면 label 1 , 하단에 부딪히면 label 2, 둘다 부딪히지 않고 기간이 만료 되면 label 0 
# 학습을 시켜서 미래의 방향을 예측하는 모델링

import FinanceDataReader as fdr

def triple_barrier_labeling(df,upper_pct = 0.02, lower_pct = -0.02, lookahed=5):
    for idx,row in df.iterrows():
        current_price =row['Close']
        upper_barrier = current_price * (1 + upper_pct)
        lower_barrier = current_price * (1 + lower_pct)
        df.loc[idx,'upper_barrier'] = upper_barrier # 이런 구조로 만들면 자동으로 upper_barrier 컬럼이 생성이 되고 값을 upper_barrier 변수가 들어 가게 된다.
        df.loc[idx,'lower_barrier'] = lower_barrier
        
        # lookahead slice
        lookahed_start_idx = idx + 1 
        lookahed_end_idx = lookahed_start_idx + lookahed
        if lookahed_end_idx > len(df):
            break
        forward_df = df.iloc[lookahed_start_idx:lookahed_end_idx] # 시작 row 와 끝 row 를 가져옴
        #Datermine the label
        label = 0 # 처음 시작은 label 0으로 함
        for forward_idx,forward_row in forward_df.iterrows():
            current_high = forward_row['High']
            current_low = forward_row['Low']
            
            #upper 와 lower를 당일 둘 다 터치 ( 분 단위 데이터를 보지 못하므로  outlier처리)
            if current_high >= upper_barrier and current_low <= lower_barrier:
                label = 0
                break
            if current_high >= upper_barrier:
                label = 1
                break
            if current_low <= lower_barrier:
                label = 2
                break
        
        df.loc[idx,'label'] = label
        df.loc[idx,'forward_idx'] = forward_idx
        
    return df

if __name__ == '__main__'        :
    df = fdr.DataReader('005930')
    df.reset_index(inplace=True)
    df = triple_barrier_labeling(df, upper_pct=0.04, lower_pct=0.04, lookahed=10)
    print(df.to_string())