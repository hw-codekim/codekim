import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
plt.rcParams['font.family'] = 'Malgun Gothic'  # '맑은 고딕' 사용
def graph(df,corp_name):
    plt.figure(figsize=(8, 4))
    plt.plot(df['date'], df['target_price'], marker='o', linestyle='-', color='b',markersize=4,linewidth=1)

    # 제목, 축 레이블 추가
    plt.title(F'[{corp_name}]_Report_Target Price')

    # X축 날짜 포맷 조정
    plt.xticks(rotation=90)

    # 그리드 추가 (점선, 연한 회색)
    plt.grid(True, linestyle=':', color='lightgray', alpha=0.7)
    
    # tight_layout의 pad 값을 설정해 여백 조정
    # plt.tight_layout(pad=10.0)  # pad 값을 통해 위쪽 여백 조
    
    # 그래프 출력
    plt.tight_layout()
    plt.savefig(F'./레포트트렌드/{corp_name}.png', dpi=100)  # 용량을 줄이기 위해 dpi 낮추기
    plt.close()


if __name__ == '__main__':
    report = pd.read_csv('레포트.csv')
    # print(report.info())
    # corp_name = '삼성전자'
    
    corps = pd.Series(report['company_name'].unique())
    
    for corp in corps:
        try:
            df = report[report['company_name'] == corp]
            df = df[df['target_price'] != 0]
            df['date'] = df['date'].astype(str)
            graph(df,corp)
        except Exception as e:
            print(e)

        