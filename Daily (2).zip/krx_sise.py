import requests
from io import BytesIO
import pandas as pd
import numpy as np
from biz_day import Bizday
from pandas.tseries.offsets import CustomBusinessDay
import holidays
from tqdm import tqdm
import os

class Krx_sise:

    def daily_kospi(biz_day):
        gen_otp_url = 'http://data.krx.co.kr/comm/fileDn/GenerateOTP/generate.cmd'
        gen_otp = {
            'locale': 'ko_KR',
            'idxIndMidclssCd': '02',
            'trdDd': biz_day,
            'share': '2',
            'money': '4',
            'csvxls_isNo': 'false',
            'name': 'fileDown',
            'url': 'dbms/MDC/STAT/standard/MDCSTAT00101'
            }

        headers = {
                'Referer':'http://data.krx.co.kr/contents/MDC/MDI/mdiLoader/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
                }

        otp_stk = requests.post(gen_otp_url,gen_otp,headers=headers).text

        down_url = 'http://data.krx.co.kr/comm/fileDn/download_csv/download.cmd'
        down = requests.post(down_url, {'code':otp_stk}, headers=headers)
        daily_kospi_value = pd.read_csv(BytesIO(down.content), encoding='EUC-KR')
        
        daily_kospi_value = daily_kospi_value.replace({np.nan:None})
        daily_kospi_value['지수명'] = daily_kospi_value['지수명'].str.replace(' ','')
        daily_kospi_value = daily_kospi_value[~daily_kospi_value['지수명'].str.contains('외국주')]
        daily_kospi_value = daily_kospi_value.apply(pd.to_numeric,errors = 'ignore')
        daily_kospi_value.insert(0,'날짜',biz_day)
        daily_kospi_value = daily_kospi_value[(daily_kospi_value['지수명'] == '코스피')]
        return daily_kospi_value
    
    def daily_kosdaq(biz_day):
        gen_otp_url = 'http://data.krx.co.kr/comm/fileDn/GenerateOTP/generate.cmd'
        gen_otp = {
            'locale': 'ko_KR',
            'idxIndMidclssCd': '03',
            'trdDd': biz_day,
            'share': '2',
            'money': '4',
            'csvxls_isNo': 'false',
            'name': 'fileDown',
            'url': 'dbms/MDC/STAT/standard/MDCSTAT00101'
            }

        headers = {
                'Referer':'http://data.krx.co.kr/contents/MDC/MDI/mdiLoader/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
                }

        otp_stk = requests.post(gen_otp_url,gen_otp,headers=headers).text

        down_url = 'http://data.krx.co.kr/comm/fileDn/download_csv/download.cmd'
        down = requests.post(down_url, {'code':otp_stk}, headers=headers)
        daily_kosdaq_value = pd.read_csv(BytesIO(down.content), encoding='EUC-KR')
        daily_kosdaq_value = daily_kosdaq_value.replace({np.nan:None})
        daily_kosdaq_value['지수명'] = daily_kosdaq_value['지수명'].str.replace(' ','')
        daily_kosdaq_value = daily_kosdaq_value[~daily_kosdaq_value['지수명'].str.contains('외국주')]
        daily_kosdaq_value = daily_kosdaq_value.apply(pd.to_numeric,errors = 'ignore')
        daily_kosdaq_value.insert(0,'날짜',biz_day)
        daily_kosdaq_value = daily_kosdaq_value[(daily_kosdaq_value['지수명'] == '코스닥')]
        return daily_kosdaq_value
    
    def merge_sise(biz_day):
        kospi = Krx_sise.daily_kospi(biz_day)
        kosdaq = Krx_sise.daily_kosdaq(biz_day)
        df = pd.concat([kospi,kosdaq])
        df = pd.pivot_table(df,index='날짜',columns='지수명',values='종가',aggfunc='sum')
        return df
    
    def save(df): # 엑셀 저장
        try:
            if not os.path.exists('지수.csv'):
                df.to_csv('지수.csv', mode='w', encoding='utf-8-sig')
            else:
                df.to_csv('지수.csv', mode='a', encoding='utf-8-sig', header=False)
        except Exception as e:
            print(e)
        finally:    
            print(f"지수 파일이 저장되었습니다")

    
if __name__ == '__main__':

    biz_day = Bizday.biz_day()
    
    
    # inp=int(input('조회기간 입력해주세요 : '))
    inp = 5
    df = pd.DataFrame()
    for i in tqdm(range(inp)):
        try:
            start_date = pd.to_datetime(biz_day)
            
            # 한국 공휴일 가져오기
            kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
            holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

            # CustomBusinessDay 설정
            kr_business_day = CustomBusinessDay(holidays=holidays_list)
            five_days_before = start_date - (i * kr_business_day)
            start_day = five_days_before.strftime('%Y%m%d')
            sise_df = Krx_sise.merge_sise(start_day)
            df = pd.concat([df,sise_df])
        except Exception as e:
            print(e)
    print(df)
    # Krx_money.save(df)
    # print('엑셀 저장완료하였습니다.')