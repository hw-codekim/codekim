import time
import numpy as np
from functools import wraps


## 데코레이터 예제
def record_time(func):
    @wraps(func) #
    def wrapper(*args,**kwargs):
        starttime = time.time()
        result = func(*args,**kwargs)
        endtime=time.time()
        print(endtime-starttime)
        return result
    return wrapper

def log_execution(func):
    @wraps(func) # 
    def wrapper(*args,**kwargs):
        print(f'Executing {func.__name__}')
        try:
            result = func(*args,**kwargs)
        except:
            result = None
        print(f'finished {func.__name__}')
        return result
    return wrapper

@record_time
@log_execution
def main():
    for i in range(10000):
        x = np.random.rand(100)
        y = np.random.rand(100)
        z = x+y

if __name__ == '__main__':
    main()
    