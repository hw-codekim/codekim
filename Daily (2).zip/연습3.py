from fastparquet import write,ParquetFile
import pandas as pd

df = pd.read_csv('종목별20일선.csv')
df.to_parquet('가격.parquet')

file_path = '가격.parquet'
