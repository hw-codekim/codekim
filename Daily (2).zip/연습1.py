import numpy as np
import time
from loguru import logger

logger.add('./20250101.log')

logger.info('123')

while True:
    time.sleep(1)
    x = np.random.random(10)    
    logger.debug(f'{x}')
    try:
        x[12] = 123
    except Exception as e:
        logger.exception(e)
    raise Exception('off')