# 백테스트를 커스텀하게 만드는 방법

from backtesting import Strategy, Backtest
import FinanceDataReader as fdr
import pandas as pd
import pandas_ta as ta

def SMA(array,n):
    """Simple moving average"""
    return pd.Series(array).rolling(n).mean()

def RSI(array,n):
    """Relative strength index"""
    #RSI계산(기본적으로 14-period)
    df = pd.DataFrame({"Close":array})
    return ta.rsi(df["Close"],length=n)

class System(Strategy):
    level = 70
    
    def init(self):
        # Compute moving averatges the startegy demands
        self.ma10 = self.I(SMA,self.data.Close, 10)
        self.ma20 = self.I(SMA,self.data.Close, 20)
        self.ma50 = self.I(SMA,self.data.Close, 50)
        self.ma100 = self.I(SMA,self.data.Close, 100)
        
        #Compute daily RSI(30)
        self.daily_rsi = self.I(RSI,self.data.Close,14)
        
    def next(self):
        price = self.data.Close[-1]
        
        # If we don't already have a position , and 
        # if all conditions are satisfied, enter long.
        if all(
            [
                not self.position,
                self.daily_rsi[-1] > self.level, # level 70 보다 크면 
                price > self.ma10[-1] > self.ma20[-1] > self.ma50[-1] > self.ma100[-1], # 정배열일때 
            ]
        ):
            # Buy at market price on next oopen, but do 
            # set 8% fixed stop loss.
            self.buy(sl=.92*price) # sl은 stop loss 고 0.92 면 -8% 에서 stop loss 걸림
            
        # If the price closes 2% or more below 10-day MA
        # close the position , if any.
        elif price < .98 * self.ma10[-1]:
            self.position.close()

df = fdr.DataReader('005930')
bt = Backtest(df,System,commission=0.018, cash = 1_000_000)
stats = bt.run()
print(stats)
print(stats['_trades'])
bt.plot()