from threading import Thread
import time
import multiprocessing
from loguru import logger


def work(id,start,end,result):
    total = 0
    
    for i in range(start,end):
        total +=i
    result.append(total)
    return

if __name__ == '__main__':
    # start = time.time()
    
    # START, END = 0, 50000000
    
    # result = list()
    # th1 = Thread(target = work, args=(2,START, END, result))
    
    # th1.start()
    # th1.join()
    
    # th1_elapsed = round(time.time() - start,2)
    # print(th1_elapsed)
    # print(result)
    
    start = time.time()
    
    START, END = 0, 50000000
    
    result = list()
    procs = []
    for i in range(2):
        # 프로세스 수만큼 코어 할당
        p = multiprocessing.Process(target=work, args=(i,START,END,result))
        p.start()
        procs.append(p)
        logger.info(f'{i+1}번째 실행')
    
    for p in procs:
        p.join() # 프로세스가 모두 종료될때까지 대기
    
    time_elapsed2 = round(time.time()-start,2)
    # speed_up = round(time_elapsed2)
    logger.info(time_elapsed2)
    
    
    
    
# 쓰레드는 가볍지만 cpu 계산처리를 하는 작업에는 한번에 하나의 쓰레드에서만 작동함
# cpu 작업이 적고 네트워크 통신 또는 파일 읽고 소기와 같은 작업 (i/o) 이 많은 병렬 처리 프로그램에서 효과적

# 멀티프로세싱 
# 멀티 프로세서와 별개의 메모리를 사용하여 완전히 독립하여 병렬 프로그래밍이 가능
#여러개의 cpu 가 있는 멀티코어 환경에서 cpu 수 만큼 작업을 나누어 실행가능
# 프로게스는 각자가 고유한 메모리 영역을 가지기 때문에 더 많은 모메모리를 필요하 하지만
# 각각 프로세서에서 병렬로 cpu 작업을 하룻 있고 이를 이용해 여러장비에서 동작하느 ㄴ분산처리 프로그래밍도 구현이 가능

