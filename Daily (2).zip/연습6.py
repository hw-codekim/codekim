# 자체 백테스팅 코드 작성

import FinanceDataReader as fdr
import pandas as pd
import pandas_ta as ta
import numpy as np
import parmap # 멀티프로세싱

def make_indicators(df):
    df['RSI'] = ta.rsi(df['Close'],length=14)
    df['SMA10'] = ta.sma(df['Close'],length=10)
    df['SMA20'] = ta.sma(df['Close'],length=20)
    df['SMA50'] = ta.sma(df['Close'],length=50)
    df['SMA100'] = ta.sma(df['Close'],length=100)
    return df

def calculate_mdd(balance_history):
    cumulative_max = np.maximum.accumulate(balance_history)
    drawdowns= (balance_history-cumulative_max)/cumulative_max
    mdd = drawdowns.min()
    return mdd * 100 # 퍼센트로 변환

def calculate_sharpe_ratio(daily_returns,risk_free_rate=0.0):
    excess_returns = daily_returns - risk_free_rate
    if daily_returns.std() == 0:
        return 0
    sharpe_ratio = excess_returns.mean()/daily_returns.std()
    return sharpe_ratio * np.sqrt(252) #연율화

def backtest_strategy(df,initial_balance = 1_000_000,transaction_cost=0.0018):
    balance = initial_balance
    position = 0 #보유 상태 (주식 수 )
    buy_price = 0 # 매수가
    trades = [] # 거래 기록 
    balance_history = [] # 일별 잔고 기록
    for idx, row in df.iterrows():
        #매수조건 : SMA 정배열 + RSI > 70
        if (
            row['Close'] > row['SMA10'] > row['SMA20'] > row['SMA50'] > row['SMA100']
            and row['RSI'] > 70
            and position == 0 # 보유 상태가 아닌 경우
        ):
            position = balance // row['Close'] # 살수 있는 최대 주식 수
            buy_price = row['Close']
            balance -= position * buy_price
            trades.append({"Date":row.name,"Type":"Buy","Price":buy_price,"Shares":position})
            
        #매도조건:-8%손실 또는 SMA10미만
        elif(
            position > 0 # 보유상태
            and (row['Close'] < buy_price * 0.92 or row['Close'] < row['SMA10'])
        ):
            sell_price = row['Close']
            balance += position * sell_price * (1 - transaction_cost) # 매매비용 반영
            trades.append({"Date":row.name,"Type":"Sell","Price":sell_price,"Shares":position})
            position = 0 # 매도 후 보유 상태 초기화
            buy_price = 0
        #잔고기록
        current_balance = balance + (position * row['Close'])    
        balance_history.append(current_balance)
    
    # 최정 정산
    if position > 0:# 아직 보유 중인 경우
        balance += position * df.iloc[-1]['Close']
    
    #MDD계산
    mdd = calculate_mdd(balance_history)
    
    # 일별 수익률 계산
    balance_series = pd.Series(balance_history)
    daily_returns = balance_series.pct_change().dropna()
    sharpe_ratio = calculate_sharpe_ratio(daily_returns)
        
    # 총 수익률
    total_return = (balance - initial_balance) / initial_balance * 100
    
    trades_df = pd.DataFrame(trades)
    
    return total_return,mdd,sharpe_ratio,trades_df

def compute_per_stock(stock_code):
    df = fdr.DataReader(stock_code)
    df = make_indicators(df)
    total_return,mdd,sharpe_ratio,trades_df = backtest_strategy(df)
    return total_return,mdd,sharpe_ratio,trades_df





if __name__ == '__main__':
    all_codes = fdr.StockListing('KRX')['Code'].tolist()
    target_codes = all_codes[:20]
    result_list = parmap.map(compute_per_stock,target_codes, pm_processes = 4, pm_pbar=True) # 멀티프로세싱 사용
    for total_return,mdd,sharpe_ratio,trades_df in result_list:
        print(f'Total Returns: {total_return:.2f}%')
        print(f'Maximum Drawdown(MDD): {mdd:.2f}%')
        print(f'Sharpe Ratio: {sharpe_ratio:.2f}%')
        print(f'Trade History:')
        print(trades_df)