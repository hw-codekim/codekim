from krx_daily_price import Krx_daily_price
from Money_Flow import Krx_money
from krx_sise import Krx_sise
from report import Report
import pandas as pd
from tqdm import tqdm
from datetime import timedelta
import holidays
from biz_day import Bizday
from pandas.tseries.offsets import CustomBusinessDay


class Save():
    def get_data_price(inp):
        biz_day = Bizday.biz_day()
        
        price_df = pd.DataFrame()

        for i in tqdm(range(inp)):
            try:
                start_date = pd.to_datetime(biz_day)
                
                # 한국 공휴일 가져오기
                kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
                holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

                # CustomBusinessDay 설정
                kr_business_day = CustomBusinessDay(holidays=holidays_list)
                five_days_before = start_date - (i * kr_business_day)
                start_day = five_days_before.strftime('%Y%m%d')
                
                rst_df = Krx_daily_price.daily_price(start_day)
                price_df = pd.concat([price_df,rst_df])
                    
            except Exception as e:
                print(e)
        Krx_daily_price.save(price_df)
                    
    def get_data_money(inp):
        biz_day = Bizday.biz_day()
        gubuns = ['1000','3000','3100','6000','9000','8000']
        
        money_df = pd.DataFrame()
        for i in tqdm(range(inp)):
            try:
                start_date = pd.to_datetime(biz_day)
                
                # 한국 공휴일 가져오기
                kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
                holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

                # CustomBusinessDay 설정
                kr_business_day = CustomBusinessDay(holidays=holidays_list)
                five_days_before = start_date - (i * kr_business_day)
                start_day = five_days_before.strftime('%Y%m%d')
                
                for gubun in gubuns:
                    rst_df1 = Krx_money.daily_money_flow(start_day,gubun)
                    money_df = pd.concat([money_df,rst_df1])
            except Exception as e:
                print(e)
                
        Krx_money.save(money_df)

    def get_data_sise(inp):
        biz_day = Bizday.biz_day()
        df = pd.DataFrame()
        for i in tqdm(range(inp)):
            try:
                start_date = pd.to_datetime(biz_day)
                
                # 한국 공휴일 가져오기
                kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
                holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

                # CustomBusinessDay 설정
                kr_business_day = CustomBusinessDay(holidays=holidays_list)
                five_days_before = start_date - (i * kr_business_day)
                start_day = five_days_before.strftime('%Y%m%d')
                print(start_day)
                sise_df = Krx_sise.merge_sise(start_day)
                df = pd.concat([df,sise_df])
            except Exception as e:
                print(e)
                
                
        Krx_sise.save(df)
        
    def get_data_report(inp):
        biz_day = Bizday.biz_day()
    
        df = pd.DataFrame()
        for i in tqdm(range(inp)):
            try:
                start_date = pd.to_datetime(biz_day)
                
                # 한국 공휴일 가져오기
                kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
                holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

                # CustomBusinessDay 설정
                kr_business_day = CustomBusinessDay(holidays=holidays_list)
                five_days_before = start_date - (i * kr_business_day)
                start_day = five_days_before.strftime('%Y%m%d')
                report_df = Report.whynot_report(start_day)
                df = pd.concat([df,report_df])
            except Exception as e:
                print(e)
                
        Report.save(df)