import requests
from bs4 import BeautifulSoup
import re
from io import BytesIO
import pandas as pd
import numpy as np
import time
import re
from datetime import datetime,timedelta
import collections
from tqdm import tqdm
import os
from pandas.tseries.offsets import CustomBusinessDay
import holidays


class Krx_money:
    
    # if not hasattr(collections, 'Callable'):
    #     collections.Callable = collections.abc.Callable
    
    # def biz_day(): # 네이버에서 날짜가져오기
    #     url = 'https://finance.naver.com/sise/sise_index.naver?code=KOSPI'
    #     res = requests.get(url)
    #     soup = BeautifulSoup(res.text,'html.parser')

    #     parse_day = soup.select_one('#time').text
        
    #     biz_day = re.findall('[0-9]+',parse_day)
    #     biz_day = ''.join(biz_day)
    #     return biz_day

    def daily_money_flow(biz_day,gubun):
        gen_otp_url = 'http://data.krx.co.kr/comm/fileDn/GenerateOTP/generate.cmd'
        gen_otp = {
            'locale': 'ko_KR',
            'mktId': 'ALL',
            'invstTpCd': f'{gubun}',
            'strtDd': f'{biz_day}',
            'endDd': f'{biz_day}',
            'share': '1',
            'money': '1',
            'csvxls_isNo': 'false',
            'name': 'fileDown',
            'url': 'dbms/MDC/STAT/standard/MDCSTAT02401'
            }

        headers = {
                'Referer':'http://data.krx.co.kr/contents/MDC/MDI/mdiLoader/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
                }

        otp_stk = requests.post(gen_otp_url,gen_otp,headers=headers).text

        down_url = 'http://data.krx.co.kr/comm/fileDn/download_csv/download.cmd'
        down = requests.post(down_url, {'code':otp_stk}, headers=headers)
        data = pd.read_csv(BytesIO(down.content), encoding='EUC-KR')
        data = data[(~data['종목명'].str.endswith('우')) &
                    (~data['종목명'].str.contains('스팩', na=False))
                    ]
        data['거래대금_매도'] = round(data['거래대금_매도']/100000000,0)
        data['거래대금_매수'] = round(data['거래대금_매수']/100000000,0)
        data['거래대금_순매수'] = round(data['거래대금_순매수']/100000000,0)
        data = data.replace({np.nan:None})
        
        if gubun == '1000': # 금융투자
            data.insert(0,'구분','금융투자')
        elif gubun == '3000': # 투신
            data.insert(0,'구분','투신')
        elif gubun == '3100': # 사모
            data.insert(0,'구분','사모')        
        elif gubun == '6000': # 연기금
            data.insert(0,'구분','연기금')
        elif gubun == '9000': # 외국인
            data.insert(0,'구분','외국인')
        elif gubun == '8000': # 개인
            data.insert(0,'구분','개인')
        data.insert(0,'날짜',biz_day)
        data = data[['날짜','구분','종목명','거래대금_매도','거래대금_매수','거래대금_순매수']]
        time.sleep(2)
        return data
    
    def save(df): # 엑셀 저장
        try:
            cal_df = pd.pivot_table(df,index=['종목명','날짜'],columns='구분',values='거래대금_순매수',aggfunc='sum',fill_value=0)
            # cal_df['개인MA20'] = cal_df.groupby('종목명')['개인'].transform(lambda x: x.rolling(window=5).mean().round(0))
            # cal_df['금융MA20'] = cal_df.groupby('종목명')['금융투자'].transform(lambda x: x.rolling(window=5).mean().round(0))
            # cal_df['사모MA20'] = cal_df.groupby('종목명')['사모'].transform(lambda x: x.rolling(window=5).mean().round(0))
            # cal_df['연기금MA20'] = cal_df.groupby('종목명')['연기금'].transform(lambda x: x.rolling(window=5).mean().round(0))
            # cal_df['외국인MA20'] = cal_df.groupby('종목명')['외국인'].transform(lambda x: x.rolling(window=5).mean().round(0))
            # cal_df['투신MA20'] = cal_df.groupby('종목명')['투신'].transform(lambda x: x.rolling(window=5).mean().round(0))
            if not os.path.exists('거래대금.csv'):
                cal_df.to_csv('거래대금.csv', mode='w', encoding='utf-8-sig')
            else:
                cal_df.to_csv('거래대금.csv', mode='a', encoding='utf-8-sig', header=False)
        except Exception as e:
            print(e)
        finally:    
            print(f"거래대금 파일이 저장되었습니다")
# if __name__ == '__main__':

#     biz_day = Krx_money.biz_day()
#     gubuns = ['1000','3000','3100','6000','9000','8000']
#     inp=int(input('조회기간 입력해주세요 : '))
    
#     df = pd.DataFrame()
#     for i in tqdm(range(inp)):
#         try:
#             start_date = pd.to_datetime(biz_day)
            
#             # 한국 공휴일 가져오기
#             kr_holidays = holidays.Korea(years=[2024])  # 2024년 공휴일
#             holidays_list = list(kr_holidays.keys())  # 공휴일 날짜 리스트 생성

#             # CustomBusinessDay 설정
#             kr_business_day = CustomBusinessDay(holidays=holidays_list)
#             five_days_before = start_date - (i * kr_business_day)
#             start_day = five_days_before.strftime('%Y%m%d')

#             for gubun in gubuns:
#                 rst_df = Krx_money.daily_money_flow(start_day,gubun)
#                 df = pd.concat([df,rst_df])
#         except Exception as e:
#             print(e)
#     Krx_money.save(df)
#     print('엑셀 저장완료하였습니다.')