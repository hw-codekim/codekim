from save import Save
import threading
import time

class main:
    def __init__(self):
        pass
    
    @staticmethod  # 정적 메서드로 선언
    def action():
                
        th1 = threading.Thread(target=Save.get_data_price, args=(1,))
        th2 = threading.Thread(target=Save.get_data_money, args=(1,))
        th3 = threading.Thread(target=Save.get_data_sise, args=(1,))
        th4 = threading.Thread(target=Save.get_data_report, args=(1,))
        
        th1.start()
        th2.start()
        th3.start()
        th4.start()
        
        th1.join()
        th2.join()
        th3.join()
        th4.join()
    
    
    
    
if __name__ == '__main__':
    start = time.time()
    main.action()
    print("소요시간 : ", time.time() - start)
    
    

