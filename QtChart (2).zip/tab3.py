from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from krx_stock import Stock_sise
from krx_daily_trade import Krx_money 
from loguru import logger
from biz_day import Bizday
import time
from functools import wraps
import threading
from shared_data.shared_data import shared_m_df

def view_data():
    global shared_m_df
    if shared_m_df is not None:
        shared_m_df = shared_m_df.to_string()
        print("Data in Tab3:")
        print(shared_m_df)
    else:
        print("No data available.")

print(view_data())

class Tab3:
    def __init__(self, widget):
        self.widget = widget
        self.init_ui()

    def init_ui(self):
        
        self.date_edit = self.widget.findChild(QDateEdit, "dateEdit")
        self.kosTableWidget = self.widget.findChild(QTableWidget, "kosTableWidget")
        self.tusinTableWidget = self.widget.findChild(QTableWidget, "tusinTableWidget")
        self.samoTableWidget = self.widget.findChild(QTableWidget, "samoTableWidget")
        self.giTableWidget = self.widget.findChild(QTableWidget, "giTableWidget")
        self.search_button = self.widget.findChild(QPushButton, "search_button")
        