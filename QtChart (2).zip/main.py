import sys
import os
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from tab1 import Tab1  # Tab1 클래스를 import
from tab2 import Tab2  # Tab2 클래스를 import
from tab3 import Tab3  # Tab2 클래스를 import
from tab4 import Tab4  # Tab2 클래스를 import

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
form_class, QtBaseClass = uic.loadUiType(BASE_DIR + r'\sample.ui')


# form_class = uic.loadUiType('sample.ui')[0]

class Qchart(QMainWindow,form_class):
    def __init__(self):
        super().__init__()
        # UI 초기화
        self.setupUi(self)

        # TabWidget 접근
        self.init_tabs()
        
    def init_tabs(self):
        tab1_widget = self.tabWidget.widget(0)  # 첫 번째 탭
        tab2_widget = self.tabWidget.widget(1)  # 첫 번째 탭
        tab3_widget = self.tabWidget.widget(2)  # 첫 번째 탭
        tab4_widget = self.tabWidget.widget(3)  # 첫 번째 탭
        self.tab1 = Tab1(tab1_widget)
        self.tab2 = Tab2(tab2_widget)
        self.tab3 = Tab3(tab3_widget)
        self.tab4 = Tab3(tab4_widget)
        
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Qchart()
    window.show()
    sys.exit(app.exec_())
        
    