import pandas as pd


df = pd.read_csv('종목별20일선.csv')
df_sort = df.sort_values(by=['종목명','날짜'],ascending=True)
df_filtered = df_sort.groupby('종목명').tail(250).reset_index(drop=True)
df_filtered['종가MA5'] = df_filtered.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=5).mean().round(0))
df_filtered['종가MA20'] = df_filtered.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=20).mean().round(0))
df_filtered['종가MA200'] = df_filtered.groupby('종목명')['종가'].transform(lambda x: x.rolling(window=200).mean().round(0))
df_filtered['종가_순위'] = df_filtered.groupby('종목명')['종가'].rank(ascending=True, method='min').astype(int)
# df_filtered['Typical_Price'] = (df_filtered['고가']+df_filtered['저가']+df_filtered['종가']) /3
# df_filtered['cumTP']  = df_filtered.groupby('종목명')['Typical_Price'].transform(lambda x: (x * df_filtered.loc[x.index, '거래량']).cumsum())
# df_filtered['cumVol'] = df_filtered.groupby('종목명')['거래량'].transform(lambda x: x.cumsum())
# df_filtered['VWAP'] = df_filtered['cumTP'] / df_filtered['cumVol']
# 50일 전 종가를 가져오기 위해 shift(50) 사용
# df_filtered['50일전_종가'] = df_filtered.groupby('종목명')['종가'].shift(119)

# 50일 전과 마지막 날의 등락률 계산
# df_filtered['기등락률'] = ((df_filtered['종가'] - df_filtered['50일전_종가']) / df_filtered['50일전_종가']) * 100
selected = df_filtered.groupby('종목명').tail(1)
print(selected)
f_selected = selected[(selected['시가총액'] >= 2000) & (selected['종가MA5'] > selected['종가MA200'])& (selected['종가'] > selected['종가MA20'])]
                    
f_selected.to_clipboard()
# print(df_filtered[df_filtered['종목명'] == 'AJ네트웍스'])



# # 각 종목별로 최댓값의 위치를 찾기
# def find_max_position(group):
#     max_value_idx = group['종가'].idxmax()  # '값'은 최댓값을 찾고자 하는 컬럼 이름
#     return group.index.get_loc(max_value_idx)

# # 각 종목별 최댓값의 위치 찾기
# max_position = df_filtered.groupby('종목명').apply(find_max_position)

