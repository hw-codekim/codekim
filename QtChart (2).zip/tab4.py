from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QPainter
import pyqtgraph as pg
from loguru import logger
from baseCode import BaseCode
from biz_day import Bizday
from krx_sise_trade import SiseTrade
from report import Report
from stock_news import naver_m_news_stock
from stock_inform import stock_info
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import finplot as fplt
import webbrowser
import pandas as pd
import sys

class Tab4:
    def __init__(self, widget):
        self.widget = widget
        self.init_ui()

    def init_ui(self):
        # 예시로 여러 버튼을 찾고 연결하는 경우
        self.inputlineEdit = self.widget.findChild(QLineEdit, "inputlineEdit")
        self.label_5 = self.widget.findChild(QLabel, "label_5")
        self.inputlineEdit_2 = self.widget.findChild(QLineEdit, "inputlineEdit_2")
        self.inputlineEdit_3 = self.widget.findChild(QLineEdit, "inputlineEdit_3")
        self.inputlineEdit_4 = self.widget.findChild(QLineEdit, "inputlineEdit_4")
        
        self.tableWidget = self.widget.findChild(QTableWidget, "tableWidget")
        self.tableView_5 = self.widget.findChild(QTableView, "tableView_5")
        self.pushButton = self.widget.findChild(QPushButton, "pushButton")
        
        self.pushButton.clicked.connect(self.on_click3)
        
    def on_click3(self):
        stockName = self.inputlineEdit.text()
        self.label_5.setText(f'기준 : {stockName}')
        logger.info(f'{stockName}')
        # 테이블에 데이터 설정
        if self.tableWidget.rowCount() <= 1:
            self.tableWidget.setRowCount(2)
        if self.tableWidget.columnCount() <= 1:
            self.tableWidget.setColumnCount(2)
        self.tableWidget.setItem(1, 1, QTableWidgetItem(str(stockName)))
        