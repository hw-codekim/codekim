from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from krx_stock import Stock_sise
from krx_daily_trade import Krx_money 
from loguru import logger
from biz_day import Bizday
import time
from functools import wraps
import threading
from shared_data.shared_data import shared_m_df


class Tab1:
    def __init__(self, widget):
        self.widget = widget
        self.init_ui()

    def record_time(func):
        @wraps(func) #
        def wrapper(*args,**kwargs):
            starttime = time.time()
            result = func(*args,**kwargs)
            endtime=time.time()
            print(endtime-starttime)
            return result
        return wrapper
    
    def init_ui(self):
        
        self.date_edit = self.widget.findChild(QDateEdit, "dateEdit")
        self.kosTableWidget = self.widget.findChild(QTableWidget, "kosTableWidget")
        self.tusinTableWidget = self.widget.findChild(QTableWidget, "tusinTableWidget")
        self.samoTableWidget = self.widget.findChild(QTableWidget, "samoTableWidget")
        self.giTableWidget = self.widget.findChild(QTableWidget, "giTableWidget")
        self.search_button = self.widget.findChild(QPushButton, "search_button")
        
        self.default_date = Bizday.biz_day() 
        self.date_edit.setDate(QDate.fromString(self.default_date, 'yyyyMMdd'))

        if self.search_button:
            self.search_button.clicked.connect(self.on_search_click1)
        else:
            print("searchButton1 not found!")
            
            
    #=========================================================     
        # 오른쪽 클릭 메뉴 활성화
        self.kosTableWidget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.kosTableWidget.customContextMenuRequested.connect(self.show_context_menu)
        # 키보드 이벤트 처리 가능하도록 설정
        self.kosTableWidget.setFocusPolicy(Qt.StrongFocus)  # 키보드 이벤트 활성화
    #=========================================================
    # 복사가능하도록 
    def show_context_menu(self, position):
        # 컨텍스트 메뉴 생성
        context_menu = QMenu(self.widget)

        # '전체 선택' 액션 생성
        select_all_action = QAction("전체 선택", self.widget)
        select_all_action.triggered.connect(self.select_all)

        # '복사' 액션 생성
        copy_action = QAction("복사", self.widget)
        copy_action.triggered.connect(self.copy_table_content)

        # 메뉴에 액션 추가
        context_menu.addAction(select_all_action)
        context_menu.addAction(copy_action)

        # 마우스 위치에서 메뉴 표시
        context_menu.exec_(self.kosTableWidget.mapToGlobal(position))

    def select_all(self):
        # 테이블의 모든 셀 선택
        self.kosTableWidget.selectAll()

    def copy_table_content(self):
        # 클립보드에 접근
        clipboard = QApplication.clipboard()

        # 선택된 모든 셀 내용을 가져옴
        selected_range = self.kosTableWidget.selectedRanges()
        
        # 클립보드에 복사
        clipboard.setText(selected_range)

    def keyPressEvent(self, event: QKeyEvent):
        """키보드 단축키를 처리하는 메서드"""
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_table_content()

    
            
    # =========================================================
    # 데이터 연산
    
    # krx 에서 지정날짜 데이터를 가져옴
    def get_daily_price(self,day):
        kos = Stock_sise.daily_price(day)
        kos_rate = kos.sort_values('등락률',ascending=False)
        kos_rate = kos_rate[kos_rate['시가총액'] > 2000]
        kos_rate = kos_rate.head(15)
        return kos_rate
    
    def get_daily_trading(self,day,nums):
        global shared_m_df
        shared_m_df = Stock_sise.merge(day,nums)
        return shared_m_df
        
    # =========================================================
    def on_search_click1(self):
        print("Tab1 search_button clicked!")
        selected_date = self.date_edit.date().toString('yyyyMMdd')
        logger.info(f"선택한 날짜: {selected_date}")

        kos_rate = self.get_daily_price(selected_date) # 데이터 로드
        self.create_ratetable_widget(kos_rate)
        
        nums = ['3000','3100','6000'] # 3000 투신, 3100 사모, 6000 연기금
        for num in nums:
            if num == '3000':
                tusin = self.get_daily_trading(selected_date,num)
                tusin = tusin.head(15)
                self.create_tusintable_widget(tusin)
            
            elif num == '3100':
                samo = self.get_daily_trading(selected_date,num)
                samo = samo.head(15)
                self.create_samotable_widget(samo)
            elif num == '6000':
                gi = self.get_daily_trading(selected_date,num)
                gi = gi.head(15)
                self.create_gitable_widget(gi)

        
    def create_ratetable_widget(self, kos):
        # 데이터프레임을 kospiTableWidget에 표시
        self.kosTableWidget.setRowCount(len(kos))  # 데이터프레임 행 개수로 설정
        self.kosTableWidget.setColumnCount(len(kos.columns))  # 데이터프레임 컬럼 수로 설정
        self.kosTableWidget.setHorizontalHeaderLabels(kos.columns)  # 헤더 설정
        
        for row in range(len(kos)):
            for col in range(len(kos.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(kos.iloc[row, col]))
                if col == 0:
                    column_index = kos.columns.get_loc("종목명")
                    self.kosTableWidget.setColumnWidth(column_index, 120)
                if col == 2 or col == 1 or col == 3 or col == 4 or col == 5:
                    item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                    column_index = kos.columns.get_loc("종가")
                    self.kosTableWidget.setColumnWidth(column_index, 70)
                    column_index = kos.columns.get_loc("등락률")
                    self.kosTableWidget.setColumnWidth(column_index, 70)
                    column_index = kos.columns.get_loc("거래대금")
                    self.kosTableWidget.setColumnWidth(column_index, 70)
                    column_index = kos.columns.get_loc("시가총액")
                    self.kosTableWidget.setColumnWidth(column_index, 70)
                    column_index = kos.columns.get_loc("거래/시총")
                    self.kosTableWidget.setColumnWidth(column_index, 70)
                self.kosTableWidget.setItem(row, col, item)
                
    def create_tusintable_widget(self, df):
        # 데이터프레임을 kospiTableWidget에 표시
        self.tusinTableWidget.setRowCount(len(df))  # 데이터프레임 행 개수로 설정
        self.tusinTableWidget.setColumnCount(len(df.columns))  # 데이터프레임 컬럼 수로 설정
        self.tusinTableWidget.setHorizontalHeaderLabels(df.columns)  # 헤더 설정
        
        for row in range(len(df)):
            for col in range(len(df.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(df.iloc[row, col]))
                if col == 0:
                    column_index = df.columns.get_loc("종목명")
                    self.tusinTableWidget.setColumnWidth(column_index, 120)
                if col == 2 or col == 1 or col == 3 or col == 4 or col == 5:
                    item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                    column_index = df.columns.get_loc("순매수")
                    self.tusinTableWidget.setColumnWidth(column_index, 60)
                    column_index = df.columns.get_loc("시총대비")
                    self.tusinTableWidget.setColumnWidth(column_index, 60)
                self.tusinTableWidget.setItem(row, col, item)
    
    def create_samotable_widget(self, df):
        # 데이터프레임을 kospiTableWidget에 표시
        self.samoTableWidget.setRowCount(len(df))  # 데이터프레임 행 개수로 설정
        self.samoTableWidget.setColumnCount(len(df.columns))  # 데이터프레임 컬럼 수로 설정
        self.samoTableWidget.setHorizontalHeaderLabels(df.columns)  # 헤더 설정
        
        for row in range(len(df)):
            for col in range(len(df.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(df.iloc[row, col]))
                if col == 0:
                    column_index = df.columns.get_loc("종목명")
                    self.samoTableWidget.setColumnWidth(column_index, 120)
                if col == 2 or col == 1 or col == 3 or col == 4 or col == 5:
                    item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                    column_index = df.columns.get_loc("순매수")
                    self.samoTableWidget.setColumnWidth(column_index, 60)
                    column_index = df.columns.get_loc("시총대비")
                    self.samoTableWidget.setColumnWidth(column_index, 60)
                self.samoTableWidget.setItem(row, col, item)
    
    def create_gitable_widget(self, df):
        # 데이터프레임을 kospiTableWidget에 표시
        self.giTableWidget.setRowCount(len(df))  # 데이터프레임 행 개수로 설정
        self.giTableWidget.setColumnCount(len(df.columns))  # 데이터프레임 컬럼 수로 설정
        self.giTableWidget.setHorizontalHeaderLabels(df.columns)  # 헤더 설정
        
        for row in range(len(df)):
            for col in range(len(df.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(df.iloc[row, col]))
                if col == 0:
                    column_index = df.columns.get_loc("종목명")
                    self.giTableWidget.setColumnWidth(column_index, 120)
                if col == 2 or col == 1 or col == 3 or col == 4 or col == 5:
                    item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                    column_index = df.columns.get_loc("순매수")
                    self.giTableWidget.setColumnWidth(column_index, 60)
                    column_index = df.columns.get_loc("시총대비")
                    self.giTableWidget.setColumnWidth(column_index, 60)
                self.giTableWidget.setItem(row, col, item)