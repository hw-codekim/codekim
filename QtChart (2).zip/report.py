import requests as rq
from bs4 import BeautifulSoup
import pandas as pd
import warnings
import time
from biz_day import Bizday
warnings.filterwarnings("ignore")

class Report:
    def whynot_report(biz_day,stockName):
        url = f'https://www.whynotsellreport.com/api/reports/from/20240102/to/{biz_day}'
        html = rq.get(url)
        # 필요한 필드만 추출하여 리스트로 만들기
        data = html.json()
        
        extracted_data = []
        for report in data:
            extracted_data.append({
                'id': report['id'],
                'date': report['date'],
                'company_name': report['company_name'],
                'analyst_name': report['analyst_name'],
                'price': report['price'],
                'judge': report['judge'],
                'title': report['title'],
                'description': report['description'],
                'analyst_rank': report['analyst_rank'],
                'stock_code_id': report['stock_code_id'],
                'analyst_id': report['analyst_id'],
            })

    # 데이터프레임 생성
        df = pd.DataFrame(extracted_data)
        df['date'] = pd.to_datetime(df['date'])
        df['date'] = df['date'].dt.strftime('%Y%m%d')
        df = df.rename(columns={'price':'target_price'})
        df=df[df['company_name'] == stockName]
        df = df[['date','company_name','analyst_name','target_price','judge','title','description']]
        
        # title과 description 결합
        df["title_description"] = df["title"] + "\n" + df["description"]

        # 필요시 기존 열 삭제
        df = df.drop(columns=["title", "description"])
        df.columns = ['날짜','기업','애널','목표가','판단','제목내용']
        # time.sleep(1)
        return df
    
if __name__ == '__main__':
    day = Bizday.biz_day()
    # day = '20240102'
    start = time.time()
    df = Report.whynot_report(day,'대한전선')
    end = time.time()
    range = end-start
    print(df)
