import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import matplotlib.pyplot as plt
from matplotlib import font_manager,rc
from datetime import datetime
import FinanceDataReader as fdr
import time
import parmap

today = datetime.today().strftime('%Y%m%d')


def sp500_finance(ticker):
    url = f'https://www.choicestock.co.kr/search/financials/{ticker}/MRQ'
    res = requests.get(url)
    soup = BeautifulSoup(res.text,'html.parser')

    # dd = soup.find('div',{'class':'scroll_table'})

    head = soup.find('thead') 
    trs = head.find_all('tr')

    trs_list = []
    for tr in trs:

        trr = tr.text
        # trr = trr.strip()
        trr = trr.split('\n')

        trs_list.append(trr)
    body = soup.find('tbody') 
    items = body.find_all('tr',{'class':'tr_emphasis'})

    info_list = []
    for item in items:

        information= item.text
        # information = information.strip()
        info = information.split('\n')
        info_list.append(info)

    df = pd.DataFrame(info_list,columns=trs_list[0])
    df = df.loc[:, df.columns != '']
    df.insert(0,'sort',['매출액','영업이익','순이익'])
    df = df.set_index('sort')
    df = df.apply(lambda x : x.str.replace(',',''))
    df = df.apply(pd.to_numeric,errors='ignore')
    df = df.T
    df.sort_index(ascending=True, inplace=True)
    df['매출성장률'] = round(df['매출액'].pct_change(4) *100,0)
    df['영익성장률'] = df['영업이익'].diff(4) / abs(df['영업이익'].shift(4)) * 100
    df['영익성장률'] = round(df['영익성장률'], 0)
    df['OPM'] = round((df['영업이익']/df['매출액'])*100,1)
    df['NPM'] = round((df['순이익']/df['매출액'])*100,1)
    df.insert(0,'ticker',ticker)
    return df

def plot_dual_axis(df,ticker):
    plt.rcParams['font.family'] = 'Malgun Gothic'  # 윈도우
    plt.rcParams['axes.unicode_minus'] = False

    x_column = df.index
    left_y_column = df[['매출성장률','영익성장률']]
    # right_y_column = df['영익성장률']

    fig, ax1 = plt.subplots(figsize=(8, 4))

    # 첫 번째 y축 (왼쪽)
    ax1.plot(x_column, left_y_column['매출성장률'], color='#333333', label='매출성장률', linewidth=1.2)
    ax1.plot(x_column, left_y_column['영익성장률'], color='blue', label='영익성장률', linewidth=1.2, linestyle='-')  # MA20 선 추가
    ax1.tick_params(axis='y', labelcolor='#333333')
            
    # 두 번째 y축 (오른쪽)
    # ax2 = ax1.twinx()
    # ax2.plot(x_column, right_y_column, color='red', label='수급오실레이터', linewidth=1.2, linestyle='-')
    # ax2.tick_params(axis='y', labelcolor='red')

    # 공통 x축 설정
    ax1.grid(color='lightgray', linestyle='--', linewidth=0.5)
    
    # 범례 설정 (왼쪽 위에 통합)
    lines1, labels1 = ax1.get_legend_handles_labels()
    # lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 , labels1 , loc='upper left', fontsize=10)

    # 배경 설정
    fig.patch.set_facecolor('white')

    # 그래프 출력
    plt.title(f"[{ticker}] 시가총액과 기관+외인 수급오실레이터")
    plt.tight_layout()
    plt.show()
    
    
    
if __name__ == '__main__':
    tickers = fdr.StockListing('NASDAQ')
    target_ticker = tickers['Symbol'].head(10)
    # 멀티프로세싱 적용
    s_t = time.time()
    try:
        result_list = parmap.map(sp500_finance, target_ticker, pm_processes=4, pm_pbar=True)
    except:
        pass
    
    # print(target_ticker)
    for rst in result_list:
        try:
            print(rst)
        except:
            pass
    e_t = time.time()
    
    range_time = e_t - s_t
    print(range_time)
    
    # df = pd.DataFrame()
    # s_t = time.time()
    # for idx,ticker in target_ticker.iterrows():
    #     try:
    #         symbol = ticker['Symbol']
    #         Name = ticker['Name']
    #         result_df = sp500_finance(symbol,Name)
    #         df = pd.concat([df,result_df])
    #     except Exception as e:
    #         print(symbol,Name,e)
    # e_t = time.time()
    
    # range_time = e_t - s_t
    # print(range_time)
    # print(df)
    # df.to_clipboard()
    # gr = plot_dual_axis(df,ticker)
