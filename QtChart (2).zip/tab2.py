from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QPixmap, QImage
import pyqtgraph as pg
from loguru import logger
from baseCode import BaseCode
from biz_day import Bizday
from krx_sise_trade import SiseTrade
from report import Report
from stock_news import naver_m_news_stock
from stock_inform import stock_info
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import matplotlib.dates as mdates
import finplot as fplt
import webbrowser
import pandas as pd

class DataFetchThread(QThread):
    sise_ready = pyqtSignal(object,str)        # 시세 데이터 전달
    sise_lastdata_ready = pyqtSignal(str,str,str)
    trading_ready = pyqtSignal(object)    # 거래 데이터 전달
    news_ready = pyqtSignal(object)         # 뉴스 데이터 전달
    info_ready = pyqtSignal(object)         # 종목정보 데이터 전달
    report_ready = pyqtSignal(object)       # 레포트 데이터 전달
    error_occurred = pyqtSignal(str)      # 에러 메시지 전달

    def __init__(self, stockName, default_date, parent=None):
        super().__init__(parent)
        self.stockName = stockName
        self.default_date = default_date


    def run(self):
        try:
            logger.info(f"Fetching data for stock: {self.stockName}")
            stCode, stockCode = BaseCode.base_info(self.stockName)

            # 시세 데이터 가져오기
            sise_df = SiseTrade.merge(self.default_date, self.stockName, stCode, stockCode)
            jongga = sise_df['종가'].iloc[-1]
            sichong = sise_df['시가총액'].iloc[-1]
            ma20 = sise_df['MA20'].iloc[-1]
            # vwap = round(sise_df['VWAP'].iloc[-1],0)
            # vwap_rate = round((vwap-jongga)/jongga*100,1)
            # if sise_df['MA20'].iloc[-1] > sise_df['MA50'].iloc[-1]:
            #     baeyul = '정배열O'
            # else :
            #     baeyul = '정배열X'
            # low_up = round((sise_df['종가'].iloc[-1] - sise_df['종가'].min())/sise_df['종가'].min()*100,0)
            self.sise_lastdata_ready.emit(str(jongga),str(sichong),str(ma20))
            self.sise_ready.emit(sise_df[-120:],str(self.stockName))
            
            # 거래 데이터 가져오기
            trading_df = SiseTrade.corp_trading(self.default_date, self.stockName, stCode, stockCode)
            self.trading_ready.emit(trading_df[-120:])

            # 뉴스 데이터 가져오기
            news = naver_m_news_stock(stockCode)
            self.news_ready.emit(news)
            
            # 종목정보 데이터 가져오기
            info = stock_info(stockCode)
            self.info_ready.emit(info)
            
            # 레프트 데이터 가져오기
            report = Report.whynot_report(self.default_date,self.stockName)
            self.report_ready.emit(report)
            
        except Exception as e:
            logger.error(f"Error fetching data: {e}")
            self.error_occurred.emit(str(e))


class Tab2:
    def __init__(self, widget):
        self.widget = widget
        self.init_ui()

    def init_ui(self):
        # 예시로 여러 버튼을 찾고 연결하는 경우
        self.stockserchButton = self.widget.findChild(QPushButton, "stockserchButton")
        self.stockLineEdit = self.widget.findChild(QLineEdit, "stockLineEdit")
        self.newsTableWidget = self.widget.findChild(QTableWidget, "newsTableWidget")
        self.infoTableWidget = self.widget.findChild(QTableWidget, "infoTableWidget")
        self.reportTableWidget = self.widget.findChild(QTableWidget, "reportTableWidget")
        self.siseGraphicsView = self.widget.findChild(QGraphicsView, "siseGraphicsView")
        self.tradegraphicsView = self.widget.findChild(QGraphicsView, "tradegraphicsView")
        self.stockLabel = self.widget.findChild(QLabel, "stockLabel")
        self.infodateStockLabel = self.widget.findChild(QLabel, "infodateStockLabel")
        
        self.default_date = Bizday.biz_day()  # 예: '2025-01-02'와 같은 문자열 반환
        
        if self.stockserchButton:
            self.stockserchButton.clicked.connect(self.on_search_click2)
            
        if self.stockLineEdit:
            self.stockLineEdit.returnPressed.connect(self.on_search_click2)  
            self.stockLineEdit.textChanged.connect(self.convert_to_uppercase)
        
    #===================================
    # 데이터 연산
    
    # def get_sise(self,stockName):
    #     # endDd = Bizday.biz_day()
    #     stCode,stockCode = BaseCode.base_info(stockName)
    #     sise_df = SiseTrade.corp_sise(self.default_date,stockName,stCode,stockCode)
    #     trading_df= SiseTrade.corp_trading(self.default_date,stockName,stCode,stockCode)
    #     self.data_ready.emit(sise_df, trading_df, stockCode)
    #     return sise_df,trading_df,stockCode
    
    #===================================

    def on_search_click2(self):
        stockName = self.stockLineEdit.text()
        logger.info(f"선택한 종목: {stockName}")
        self.infodateStockLabel.setText(f'기준 : {self.default_date}')
        
        # 스레드 생성
        self.dataThread = DataFetchThread(stockName, self.default_date)
        self.dataThread.sise_ready.connect(self.on_sise_ready)
        self.dataThread.sise_lastdata_ready.connect(self.update_stock_label)
        self.dataThread.trading_ready.connect(self.on_trading_ready)
        self.dataThread.news_ready.connect(self.on_news_ready)
        self.dataThread.info_ready.connect(self.on_info_ready)
        self.dataThread.report_ready.connect(self.on_report_ready)
        self.dataThread.error_occurred.connect(self.on_error)
        self.dataThread.start()
        
        
        
        
        
    # 시세 데이터 준비 완료   
    def on_sise_ready(self, sise_df, stockName):
        logger.info("시세 데이터 가져오기 완료")
        self.chart_sise(sise_df,stockName)    
    
    # 거래 데이터 준비 완료
    def on_trading_ready(self, trading_df):
        logger.info("거래 데이터 가져오기 완료")
        self.chart_trading(trading_df)

    # 뉴스 데이터 준비 완료
    def on_news_ready(self, news):
        logger.info("뉴스 데이터 가져오기 완료")
        self.create_news_table_widget(news)

    # 종목정보 준비 완료
    def on_info_ready(self, info):
        logger.info("종목정보 데이터 가져오기 완료")
        self.create_info_table_widget(info)
    
    # 종목정보 준비 완료
    def on_report_ready(self, report):
        logger.info("레포트 데이터 가져오기 완료")
        self.create_report_table_widget(report)
        
    # 에러 발생시
    def on_error(self, error_message):
        QMessageBox.critical(self.widget, "Error", f"데이터 가져오기 실패: {error_message}")

    # 입력된 텍스트를 대문자로 변환
    def update_stock_label(self, jongga, vwap, vwap_rate, baeyul ,low_up):
        # 받은 데이터를 포맷팅하여 QLabel에 표시
        # text = f"종가 : {jongga}원 | VWAP : {vwap}원 | 타겟 : {vwap_rate}% | {baeyul} | 저점대비 : {low_up}%"
        text = (f"종가 : <font color='blue'>{jongga}원</font> | "
            f"VWAP : <font color='blue'>{vwap}원</font> | "
            f"타겟 : <font color='blue'>{vwap_rate}%</font> | "
            f"{baeyul} | 저점대비 : <font color='blue'>{low_up}%</font>")
        
        self.stockLabel.setText(text)
    
    # 입력된 텍스트를 대문자로 변환
    def convert_to_uppercase(self, text):
        uppercase_text = text.upper()
        # QLineEdit의 텍스트를 대문자로 업데이트
        if text != uppercase_text:
            self.stockLineEdit.blockSignals(True)  # 시그널 차단하여 무한 루프 방지
            self.stockLineEdit.setText(uppercase_text)
            self.stockLineEdit.blockSignals(False)    
    
    def create_news_table_widget(self, news):
        self.newsTableWidget.setRowCount(len(news))  # 행 개수 설정
        self.newsTableWidget.setColumnCount(3)  # 열 개수 설정
        self.newsTableWidget.setHorizontalHeaderLabels(['날짜','제목', '링크'])

        for row in range(len(news)):
            date_item = QTableWidgetItem(str(news.iloc[row]['날짜']))
            title_item = QTableWidgetItem(news.iloc[row]['제목'])
            # 버튼 생성
            link_button = QPushButton("연결")
            link_url = news.iloc[row]['링크']           
            # 버튼에 클릭 이벤트 연결
            link_button.clicked.connect(lambda _, url=link_url: webbrowser.open(url))
            # 셀에 내용 삽입
            self.newsTableWidget.setItem(row, 0, date_item)
            self.newsTableWidget.setItem(row, 1, title_item)
            # self.newsTableWidget.setItem(row, 2, link_item)
            self.newsTableWidget.setCellWidget(row, 2, link_button)
            # 크기 조정
            self.newsTableWidget.setColumnWidth(0, 90)  # 날짜 열
            self.newsTableWidget.setColumnWidth(1, 350)  # 제목 열
            self.newsTableWidget.setColumnWidth(2, 60)  # 링크 열

    def create_info_table_widget(self, info):
        self.infoTableWidget.setRowCount(len(info))  # 행 개수 설정
        self.infoTableWidget.setColumnCount(2)  # 열 개수 설정
        self.infoTableWidget.setHorizontalHeaderLabels(info.columns)
        for row in range(len(info)):
            for col in range(len(info.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(info.iloc[row, col]))
                # if col == 0:
                #     column_index = info.columns.get_loc("항목")
                self.infoTableWidget.setColumnWidth(0, 75)
                if col == 1:
                    item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                    column_index = info.columns.get_loc("값")
                    self.infoTableWidget.setColumnWidth(column_index, 85)
                self.infoTableWidget.setItem(row, col, item)
                
    def create_report_table_widget(self, report):
        self.reportTableWidget.setRowCount(len(report))  # 행 개수 설정
        self.reportTableWidget.setColumnCount(6)  # 열 개수 설정
        self.reportTableWidget.setHorizontalHeaderLabels(report.columns)
        
        # 열 너비 미리 설정
        self.reportTableWidget.setColumnWidth(0, 75)
        self.reportTableWidget.setColumnWidth(1, 85)
        self.reportTableWidget.setColumnWidth(2, 55)
        self.reportTableWidget.setColumnWidth(3, 65)
        self.reportTableWidget.setColumnWidth(4, 65)
        self.reportTableWidget.setColumnWidth(5, 300)
        
        for row in range(len(report)):
            for col in range(len(report.columns)):
                # 데이터프레임의 각 셀 값을 QTableWidgetItem으로 추가
                item = QTableWidgetItem(str(report.iloc[row, col]))
                item.setTextAlignment(Qt.AlignVCenter | Qt.AlignRight)
                # 제목내용 컬럼에 대해서만 word wrap 활성화
                if col == 5:  # 제목내용 컬럼
                    item.setTextAlignment(Qt.AlignTop | Qt.AlignLeft)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)  # 읽기 전용으로 설정
                
                self.reportTableWidget.setItem(row, col, item)
        # 셀 크기 자동 조정
        self.reportTableWidget.resizeRowsToContents()  # 행 높이를 내용에 맞게 조정
        # self.reportTableWidget.resizeColumnsToContents()  # 열 너비를 내용에 맞게 조정
        # 스타일 시트로 텍스트 줄바꿈 활성화
        self.reportTableWidget.setStyleSheet("QTableWidget::item { word-wrap: break-word; }")
        
        
    def chart_trading(self, trading_df):
        # QGraphicsScene 생성
        scene = QGraphicsScene(self.widget)
        self.tradegraphicsView.setScene(scene)
        # PyQtGraph PlotWidget 생성
        plot_widget = pg.PlotWidget()
        # 그래프 크기 조정
        plot_widget.setFixedSize(521, 251)  # 원하는 크기 (가로, 세로)
        # 배경을 하얀색으로 설정
        plot_widget.setBackground('w')
        # 연한 회색 점선 그리드 추가
        plot_widget.showGrid(x=True, y=True, alpha=0.3)  # alpha를 0.3으로 설정하여 연하게

        # X축 (Index)와 Y축 (투신_누적) 데이터 설정
        # x_labels = trading_df.index.strftime('%y%m%d')  # 날짜를 '월-일' 형식으로 변환
        # x_data = list(range(len(x_labels)))
        x_data = trading_df['일자']
        y_data1 = trading_df['기관_']
        y_data2 = trading_df['개인_']
        y_data3 = trading_df['외국인_']
        # logger.info(x_data)
        
        plot_widget.addLegend(size=(50, 10),offset=(5,1))
        
        # 그래프 그리기
        plot_widget.plot(x=x_data, y=y_data1, pen=pg.mkPen(color='b', width=2, style=pg.QtCore.Qt.SolidLine), name='기관', antialias=True)
        plot_widget.plot(x=x_data, y=y_data2, pen=pg.mkPen(color='purple', width=2, style=pg.QtCore.Qt.SolidLine), name='개인', antialias=True)
        plot_widget.plot(x=x_data, y=y_data3, pen=pg.mkPen(color='r', width=2, style=pg.QtCore.Qt.SolidLine), name='외국인', antialias=True)
        
        # 마우스 휠 확대/축소 비활성화
        plot_widget.setMouseEnabled(x=False, y=False)  # 확대/축소와 이동을 고정 상태로 설정

        # 그래프 위젯을 Scene에 추가
        scene.addWidget(plot_widget)
    
    # def chart_sise(self, sise_df):
    #     # QGraphicsScene 생성
    #     scene = QGraphicsScene(self.widget)
    #     self.siseGraphicsView.setScene(scene)

    #     # PyQtGraph PlotWidget 생성
    #     plot_widget = pg.PlotWidget()

    #     # 그래프 크기 조정
    #     plot_widget.setFixedSize(521, 251)  # 원하는 크기 (가로, 세로)

    #     # 배경을 하얀색으로 설정
    #     plot_widget.setBackground('w')

    #     # 연한 회색 점선 그리드 추가
    #     plot_widget.showGrid(x=True, y=True, alpha=0.3)  # alpha를 0.3으로 설정하여 연하게

    #     # X축 (Index)와 Y축 데이터 설정
    #     x_data = sise_df.index
    #     y_data1 = sise_df['종가']
    #     y_data2 = sise_df['VWAP']
    #     y_data3 = sise_df['MA50']
    #     # volume_data = sise_df['거래대금']

    #     plot_widget.addLegend(size=(50, 10), offset=(5, 1))

    #     # 선 그래프 그리기
    #     plot_widget.plot(x=x_data, y=y_data1, pen=pg.mkPen(color='navy', width=2, style=pg.QtCore.Qt.SolidLine), name='종가', antialias=True)
    #     plot_widget.plot(x=x_data, y=y_data2, pen=pg.mkPen(color='darkgreen', width=2, style=pg.QtCore.Qt.SolidLine), name='VWAP', antialias=True)
    #     plot_widget.plot(x=x_data, y=y_data3, pen=pg.mkPen(color='orange', width=2, style=pg.QtCore.Qt.SolidLine), name='50일', antialias=True)

    #     plot_widget.setMouseEnabled(x=False, y=False)  # 확대/축소와 이동을 고정 상태로 설정

    #     # 그래프 위젯을 Scene에 추가
    #     scene.addWidget(plot_widget)
        
    def chart_sise(self, df,stockName):
            # Matplotlib로 그래프 생성
        plt.rcParams['font.family'] = 'Malgun Gothic'  # 윈도우
        plt.rcParams['axes.unicode_minus'] = False

        x_column = df['일자']
        left_y_column = df[['종가', 'MA20']]
        right_y_column = df['수급오실레이터']

        fig, ax1 = plt.subplots(figsize=(5.5, 2.5))

        # 첫 번째 Y축 (왼쪽)
        ax1.plot(x_column, left_y_column['종가'], color='#333333', label='종가', linewidth=1.2)
        ax1.plot(x_column, left_y_column['MA20'], color='blue', label='MA20', linewidth=1.2, linestyle='-')
        ax1.tick_params(axis='y', labelleft = False,labelcolor='#333333')
        # ax1.set_xlabel('일자')
        # ax1.set_ylabel('종가 및 MA20')

        # 두 번째 Y축 (오른쪽)
        ax2 = ax1.twinx()
        ax2.plot(x_column, right_y_column, color='red', label='수급오실레이터', linewidth=1.2, linestyle='-')
        ax2.tick_params(axis='y', labelright = False,labelcolor='red')
        # ax2.set_ylabel('수급오실레이터')

        # 범례 설정
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=8)

        # 제목 설정
        # plt.title(f"[{stockName}] 시가총액과 기관+외인 수급오실레이터")
        plt.tight_layout()

        # Matplotlib 그래프를 이미지로 저장
        canvas = FigureCanvas(fig)
        canvas.draw()
        width, height = canvas.get_width_height()
        img = QImage(canvas.buffer_rgba(), width, height, QImage.Format_ARGB32)

        # QGraphicsScene 생성 및 QGraphicsView에 이미지 설정
        scene = QGraphicsScene(self.siseGraphicsView)
        self.siseGraphicsView.setScene(scene)
        pixmap = QPixmap.fromImage(img)
        scene.addPixmap(pixmap)

        # Matplotlib 자원 해제
        plt.close(fig)