import requests
from bs4 import BeautifulSoup
import pandas as pd


# def stock_info(stockCode):
#     dic = {
#         '주가': '',
#         '등락률': '',
#         '최고52' :'',
#         '최저52': '',
#         '거래량' : '',
#         '거래대금': '',
#         '시총' : '',
#         '총주식수': '',
#         '유통비율' : '',
#         '외인지분' : '',
#         '수익률1M': '',
#         '수익률3M': '',
#         '수익률6M': '',
#         '수익률1Y': '',
#         'PER24E': '',
#         'PBR24E': '',
#         'EPS24E': '',
#         'BPS24E': '',
#         '배당24E': ''
#         }

#     url = f'https://navercomp.wisereport.co.kr/v2/company/c1010001.aspx?cmp_cd={stockCode}'

#     req = requests.get(url)
#     soup = BeautifulSoup(req.content,'html.parser')

#     soup_tag = soup.find('table',attrs={'id':'cTB11'})
#     tr_tag=soup_tag.find_all('tr')

#     주가 = tr_tag[0].text.split('\n')[3].strip().replace(' /','')
#     등락률 = tr_tag[0].text.split('\n')[4].split('/')[1].strip()
#     최고52 = tr_tag[1].text.split('\n')[3].strip().replace(' /','')
#     최저52 = tr_tag[1].text.split('\n')[4].strip()
#     거래량 = tr_tag[3].text.split('\n')[3].strip().replace(' /','')
#     거래대금 = tr_tag[3].text.split('\n')[4].strip()
#     시총 = tr_tag[4].text.split('\n')[3].strip()
#     총주식수 = tr_tag[6].text.split('\n')[3].split('/')[0].strip()
#     유통비율 = tr_tag[6].text.split('\n')[3].split('/')[1].strip()
#     외인지분 = tr_tag[7].text.split('\n')[3].strip()
#     수익률1M = tr_tag[8].text.split('\n')[3].split('/')[0].strip()
#     수익률3M = tr_tag[8].text.split('\n')[3].split('/')[1].strip()
#     수익률6M = tr_tag[8].text.split('\n')[3].split('/')[2].strip()
#     수익률1Y = tr_tag[8].text.split('\n')[3].split('/')[3].strip()

#     soup_tag = soup.find('table',attrs={'class':'gHead03'})
#     tr3_tag=soup_tag.find_all('tr')

#     per24E = tr3_tag[1].text.split('\n')[3]
#     pbr24E = tr3_tag[2].text.split('\n')[3]
#     eps24E = tr3_tag[5].text.split('\n')[3]
#     bps24E = tr3_tag[6].text.split('\n')[3]
#     배당24E = tr3_tag[9].text.split('\n')[3]

#     dic['주가'] = 주가
#     dic['등락률'] = 등락률
#     dic['최고52'] = 최고52
#     dic['최저52'] = 최저52
#     dic['거래량'] = 거래량
#     dic['거래대금'] = 거래대금
#     dic['시총'] = 시총
#     dic['총주식수'] = 총주식수
#     dic['유통비율'] = 유통비율
#     dic['외인지분'] = 외인지분
#     dic['수익률1M'] = 수익률1M
#     dic['수익률3M'] = 수익률3M
#     dic['수익률6M'] = 수익률6M
#     dic['수익률1Y'] = 수익률1Y
#     dic['PER24E'] = per24E
#     dic['PBR24E'] = pbr24E
#     dic['EPS24E'] = eps24E
#     dic['BPS24E'] = bps24E
#     dic['배당24E'] = 배당24E


#     soup_tag = soup.find('table',attrs={'id':'cTB13'})
#     tr2_tag=soup_tag.find_all('tr')

#     #주주1
#     span_icon1 = tr2_tag[1].find('span', attrs={'class': 'icon-sprite'})
#     span_cut1 = tr2_tag[1].find('span', attrs={'class': 'cut'})

#     if span_icon1:
#         주요주주1 = span_icon1.text.strip()
#     elif span_cut1:
#         주요주주1 = span_cut1.text.strip()
#     else:
#         주요주주1 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
#     주주1지분 = tr2_tag[1].text.split('\n')[5].strip()

#     #주주2
#     span_icon2 = tr2_tag[2].find('span', attrs={'class': 'icon-sprite'})
#     span_cut2 = tr2_tag[2].find('span', attrs={'class': 'cut'})

#     if span_icon2:
#         주요주주2 = span_icon2.text.strip()
#     elif span_cut2:
#         주요주주2 = span_cut2.text.strip()
#     else:
#         주요주주2 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
#     주주2지분 = tr2_tag[2].text.split('\n')[5].strip()

#     #주주3
#     span_icon3 = tr2_tag[3].find('span', attrs={'class': 'icon-sprite'})
#     span_cut3 = tr2_tag[3].find('span', attrs={'class': 'cut'})

#     if span_icon3:
#         주요주주3 = span_icon3.text.strip()
#     elif span_cut3:
#         주요주주3 = span_cut3.text.strip()
#     else:
#         주요주주3 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
#     주주3지분 = tr2_tag[3].text.split('\n')[5].strip()

#     #주주4
#     span_icon4 = tr2_tag[4].find('span', attrs={'class': 'icon-sprite'})
#     span_cut4 = tr2_tag[4].find('span', attrs={'class': 'cut'})

#     if span_icon4:
#         주요주주4 = span_icon4.text.strip()
#     elif span_cut4:
#         주요주주4 = span_cut4.text.strip()
#     else:
#         주요주주4 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
#     주주4지분 = tr2_tag[4].text.split('\n')[5].strip()
#     dic.update({'주요주주':'',주요주주1:주주1지분,주요주주2:주주2지분,주요주주3:주주3지분,주요주주4:주주4지분})
#     df = pd.DataFrame(list(dic.items()), columns=['항목', '값'])
#     df = df[df['항목'] != '']
#     df['값'] = df['값'].str.strip()
#     return df
# #주식 가격
# def stock_price(stock_code):

#     base_url = 'https://finance.naver.com/item/main.naver'
#     url = base_url + '?code=' + stock_code

#     html = requests.get(url).text
#     soup = BeautifulSoup(html, 'html.parser')

#     stock_price = soup.select_one('p.no_today span.blind').get_text()
#     stock_price_pm = soup.select('p.no_exday span.ico')[1].get_text()
#     stock_price_y = soup.select('p.no_exday span.blind')[1].get_text()
#     sichong = soup.select_one('#_market_sum').text.strip()
#     jusik_cnt = soup.select('#tab_con1 > div.first > table > tbody > tr:nth-child(3)')
#     stock_rate = stock_price_pm + stock_price_y
#     stock_price = stock_price.replace(',','')
    
#     return jusik_cnt
#주식 가격
def stock_info(stockCode):
    
    dic = {
        '주가': '',
        '등락률': '',
        '거래량' : '',
        '거래대금': '',
        '시총' : '',
        '주식수': '',
        '최고52' :'',
        '최저52': '',
        '외인지분' : '',
        'PER': '',
        'EPS': '',
        }
    
    base_url = 'https://finance.naver.com/item/sise.naver'
    url = base_url + '?code=' + stockCode

    html = requests.get(url).text
    soup = BeautifulSoup(html, 'html.parser')

    soup_tag = soup.find('table', attrs={'class': 'type2'})
    tr_tag=soup_tag.find_all('tr')
    주가 = tr_tag[0].text.split('\n')[2]
    등락률 = tr_tag[2].text.split('\n')[4].strip()
    거래량 = tr_tag[3].text.split('\n')[2]
    거래대금 = tr_tag[4].text.split('\n')[6].strip()
    if 거래대금 == '':
        거래대금 = tr_tag[4].text.split('\n')[5].strip()
    PER = tr_tag[9].text.split('\n')[5].strip()
    EPS = tr_tag[9].text.split('\n')[1].strip()
    최고52 = tr_tag[10].text.split('\n')[2].strip()
    최저52 = tr_tag[10].text.split('\n')[4].strip()
    시총 = tr_tag[11].text.split('\n')[2].strip()
    주식수 = tr_tag[11].text.split('\n')[4].strip()
    cur_forcnt = int(tr_tag[12].text.split('\n')[2].strip().replace("천주",'000').replace(",",''))
    외인지분 = round(cur_forcnt/int(주식수.replace(',',''))*100,1)
    
    dic['주가'] = 주가
    dic['등락률'] = 등락률
    dic['거래량'] = 거래량
    dic['거래대금'] = 거래대금
    dic['PER'] = PER
    dic['EPS'] = EPS
    dic['최고52'] = 최고52
    dic['최저52'] = 최저52
    dic['시총'] = 시총
    dic['주식수'] = 주식수
    dic['외인지분'] = str(외인지분)

    
    url = f'https://navercomp.wisereport.co.kr/v2/company/c1010001.aspx?cmp_cd={stockCode}'

    req = requests.get(url)
    soup = BeautifulSoup(req.content,'html.parser')
    
    
    
    soup_tag = soup.find('table',attrs={'id':'cTB13'})
    tr2_tag=soup_tag.find_all('tr')

    #주주1
    span_icon1 = tr2_tag[1].find('span', attrs={'class': 'icon-sprite'})
    span_cut1 = tr2_tag[1].find('span', attrs={'class': 'cut'})

    if span_icon1:
        주요주주1 = span_icon1.text.strip()
    elif span_cut1:
        주요주주1 = span_cut1.text.strip()
    else:
        주요주주1 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
    주주1지분 = tr2_tag[1].text.split('\n')[5].strip()

    #주주2
    span_icon2 = tr2_tag[2].find('span', attrs={'class': 'icon-sprite'})
    span_cut2 = tr2_tag[2].find('span', attrs={'class': 'cut'})

    if span_icon2:
        주요주주2 = span_icon2.text.strip()
    elif span_cut2:
        주요주주2 = span_cut2.text.strip()
    else:
        주요주주2 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
    주주2지분 = tr2_tag[2].text.split('\n')[5].strip()

    #주주3
    span_icon3 = tr2_tag[3].find('span', attrs={'class': 'icon-sprite'})
    span_cut3 = tr2_tag[3].find('span', attrs={'class': 'cut'})

    if span_icon3:
        주요주주3 = span_icon3.text.strip()
    elif span_cut3:
        주요주주3 = span_cut3.text.strip()
    else:
        주요주주3 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
    주주3지분 = tr2_tag[3].text.split('\n')[5].strip()

    #주주4
    span_icon4 = tr2_tag[4].find('span', attrs={'class': 'icon-sprite'})
    span_cut4 = tr2_tag[4].find('span', attrs={'class': 'cut'})

    if span_icon4:
        주요주주4 = span_icon4.text.strip()
    elif span_cut4:
        주요주주4 = span_cut4.text.strip()
    else:
        주요주주4 = None  # 혹은 '데이터 없음'과 같이 기본값 설정
    주주4지분 = tr2_tag[4].text.split('\n')[5].strip()
    dic.update({'주요주주':'',주요주주1:주주1지분,주요주주2:주주2지분,주요주주3:주주3지분,주요주주4:주주4지분})
    df = pd.DataFrame(list(dic.items()), columns=['항목', '값'])
    df = df[df['항목'] != '']
    df['값'] = df['값'].str.strip()

    return df
if __name__ == '__main__':
    df = stock_info('009830')
    print(df)