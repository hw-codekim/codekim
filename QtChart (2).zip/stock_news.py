import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime,timedelta

def naver_m_news_stock(corp_code):

    col = ['날짜','제목','링크']
    lst = []
    for i in range(1,5):
        url = f'https://m.stock.naver.com/api/news/stock/{corp_code}?pageSize=20&page={i}'
        res = requests.get(url)
        js = res.json()

        for idx,content in enumerate(js):
            datetime = content['items'][0]['datetime']
            # officeName = content['items'][0]['officeName']
            title = content['items'][0]['title']
            # body = content['items'][0]['body']
            base_link = 'https://n.news.naver.com/article/'
            link = base_link + content['items'][0]['officeId'] +'/'+ content['items'][0]['id'][3:]
            # lst.append([datetime,officeName,title,body,link])
            lst.append([datetime,title,link])

    df = pd.DataFrame(lst,columns=col) 
    # df.insert(0,'종목',corp_name)
    df['날짜'] = df['날짜'].apply(lambda x: f"{x[:4]}-{x[4:6]}-{x[6:8]}")
    df['제목'] = df['제목'].str.replace('&quot;','')
    return df 


if __name__ == '__main__':
    # ddf =get_search_naver('아톤')
    df = naver_m_news_stock('009470','삼화전기')
    print(df)